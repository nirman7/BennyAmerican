package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class SlideModel implements Parcelable {

    String sp_id;
    String cat_id;
    String pro_name;
    String img;
    String status;

    public String getSp_id() {
        return sp_id;
    }

    public void setSp_id(String sp_id) {
        this.sp_id = sp_id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getPro_name() {
        return pro_name;
    }

    public void setPro_name(String pro_name) {
        this.pro_name = pro_name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    protected SlideModel(Parcel in) {
        sp_id = in.readString();
        cat_id = in.readString();
        pro_name = in.readString();
        img = in.readString();
        status = in.readString();
    }

    public static final Creator<SlideModel> CREATOR = new Creator<SlideModel>() {
        @Override
        public SlideModel createFromParcel(Parcel in) {
            return new SlideModel(in);
        }

        @Override
        public SlideModel[] newArray(int size) {
            return new SlideModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(sp_id);
        dest.writeString(cat_id);
        dest.writeString(pro_name);
        dest.writeString(img);
        dest.writeString(status);
    }
}
