package com.benny.app.services.helper;

/**
 * Created by user on 18/04/2020.
 */
public interface ServiceResponse {
    void requestResponse(String result);

}
