package com.benny.app.views.fragment;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.adapter.CategoryAdapter;
import com.google.gson.Gson;
import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.CategoryModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created Jitendra Sharma on 27/05/2020.
 */
public class HomeFragment extends BaseFragment {

    @BindView(R.id.recyclerView_list)
    RecyclerView recyclerView;

    private View convertView;
    private Unbinder unbinder;
    private FragmentActivity mActivity;
    private HeaderLayout mHeaderLayout;
    private CategoryAdapter categoryAdapter;
    private ArrayList<CategoryModel> mMenuList = new ArrayList<>();

    public static HomeFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        HomeFragment fragment = new HomeFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.convertView = inflater.inflate(R.layout.fragment_home, null);
        this.unbinder = ButterKnife.bind(this, convertView);
        return convertView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        this.mActivity = getActivity();

        try {
            String title = getArguments().getString("Title");
            this.mHeaderLayout.setHeaderValues(0, "logo", 0);
            this.mHeaderLayout.setListenerItI(null, null);

            setAdapter();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    private void setAdapter() {

        final LinearLayoutManager manager = new LinearLayoutManager(mActivity);
        recyclerView.setLayoutManager(manager);
        categoryAdapter = new CategoryAdapter(mActivity, new CategoryAdapter.AdapterCallBack() {
            @Override
            public void itemClickListener(CategoryModel model) {
               switchFragment(0, model);
            }
        });
        recyclerView.setAdapter(categoryAdapter);

        getCategoryList();
    }

    private void getCategoryList() {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "category_list");
            jsonObject.put("user_id", userModel.getUid());
            jsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("category_list", "jsonObject: " + jsonObject.toString());

            NetworkApiCall service = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    logConfig.printP("category_list", "result: " + result);
                    parseList(result);
                }
            });
            service.call();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void parseList(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");
            mMenuList.clear();

            if (status.equalsIgnoreCase("true")) {
                JSONObject data = jsonObject.getJSONObject("data");
                JSONArray jsonArrayCat = data.getJSONArray("category");
                Gson gson = new Gson();
                for (int i = 0; i < jsonArrayCat.length(); i++) {
                    JSONObject jsonObject1 = jsonArrayCat.getJSONObject(i);
                    CategoryModel model = gson.fromJson(jsonObject1.toString(), CategoryModel.class);
                    mMenuList.add(model);
                }
            } else {
                logConfig.printToast(mActivity, message);
            }
            categoryAdapter.setList(mMenuList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    BaseFragment mBaseFragment = null;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;

    private void switchFragment(int position, CategoryModel model) {
        Bundle mBundle = new Bundle();
        mBundle.putParcelable("CategoryModel", model);
        switch (position) {
            case 0:
                mBundle.putString("Title", "Product List");
                mBaseFragment = ProductsFragment.getInstance(mHeaderLayout, false);
                if (mBaseFragment != null) {
                    mBaseFragment.setArguments(mBundle);
                    mFragmentManager = mActivity.getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("ProductsFragment");
                    mFragmentTransaction.commit();
                }
                break;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
