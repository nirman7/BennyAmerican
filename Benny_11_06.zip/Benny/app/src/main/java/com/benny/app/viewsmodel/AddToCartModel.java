package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class AddToCartModel implements Parcelable {

    String pro_id;
    String cat_id;
    String sub_id;
    String pro_name;
    String pro_price;
    String pro_offer_price;
    String pro_description;
    String pro_img;
    String pro_stock;
    String pro_status;
    String card_id;
    String card_uid;
    String card_cat_id;
    String card_sub_id;
    String card_pro_id;
    String card_pro_quantity;
    String card_pro_price;
    String card_total_price;

    public String getPro_id() {
        return pro_id;
    }

    public void setPro_id(String pro_id) {
        this.pro_id = pro_id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getPro_name() {
        return pro_name;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public void setPro_name(String pro_name) {
        this.pro_name = pro_name;
    }

    public String getPro_price() {
        return pro_price;
    }

    public void setPro_price(String pro_price) {
        this.pro_price = pro_price;
    }

    public String getPro_offer_price() {
        return pro_offer_price;
    }

    public void setPro_offer_price(String pro_offer_price) {
        this.pro_offer_price = pro_offer_price;
    }

    public String getPro_description() {
        return pro_description;
    }

    public void setPro_description(String pro_description) {
        this.pro_description = pro_description;
    }

    public String getPro_img() {
        return pro_img;
    }

    public void setPro_img(String pro_img) {
        this.pro_img = pro_img;
    }

    public String getPro_stock() {
        return pro_stock;
    }

    public void setPro_stock(String pro_stock) {
        this.pro_stock = pro_stock;
    }

    public String getPro_status() {
        return pro_status;
    }

    public void setPro_status(String pro_status) {
        this.pro_status = pro_status;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getCard_uid() {
        return card_uid;
    }

    public void setCard_uid(String card_uid) {
        this.card_uid = card_uid;
    }

    public String getCard_cat_id() {
        return card_cat_id;
    }

    public void setCard_cat_id(String card_cat_id) {
        this.card_cat_id = card_cat_id;
    }

    public String getCard_sub_id() {
        return card_sub_id;
    }

    public void setCard_sub_id(String card_sub_id) {
        this.card_sub_id = card_sub_id;
    }

    public String getCard_pro_id() {
        return card_pro_id;
    }

    public void setCard_pro_id(String card_pro_id) {
        this.card_pro_id = card_pro_id;
    }

    public String getCard_pro_quantity() {
        return card_pro_quantity;
    }

    public void setCard_pro_quantity(String card_pro_quantity) {
        this.card_pro_quantity = card_pro_quantity;
    }

    public String getCard_pro_price() {
        return card_pro_price;
    }

    public void setCard_pro_price(String card_pro_price) {
        this.card_pro_price = card_pro_price;
    }

    public String getCard_total_price() {
        return card_total_price;
    }

    public void setCard_total_price(String card_total_price) {
        this.card_total_price = card_total_price;
    }



    protected AddToCartModel(Parcel in) {
        pro_id = in.readString();
        cat_id = in.readString();
        sub_id = in.readString();
        pro_name = in.readString();
        pro_price = in.readString();
        pro_offer_price = in.readString();
        pro_description = in.readString();
        pro_img = in.readString();
        pro_stock = in.readString();
        pro_status = in.readString();
        card_id = in.readString();
        card_uid = in.readString();
        card_cat_id = in.readString();
        card_sub_id = in.readString();
        card_pro_id = in.readString();
        card_pro_quantity = in.readString();
        card_pro_price = in.readString();
        card_total_price = in.readString();
    }

    public static final Creator<AddToCartModel> CREATOR = new Creator<AddToCartModel>() {
        @Override
        public AddToCartModel createFromParcel(Parcel in) {
            return new AddToCartModel(in);
        }

        @Override
        public AddToCartModel[] newArray(int size) {
            return new AddToCartModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(pro_id);
        dest.writeString(cat_id);
        dest.writeString(sub_id);
        dest.writeString(pro_name);
        dest.writeString(pro_price);
        dest.writeString(pro_offer_price);
        dest.writeString(pro_description);
        dest.writeString(pro_img);
        dest.writeString(pro_stock);
        dest.writeString(pro_status);
        dest.writeString(card_id);
        dest.writeString(card_uid);
        dest.writeString(card_cat_id);
        dest.writeString(card_sub_id);
        dest.writeString(card_pro_id);
        dest.writeString(card_pro_quantity);
        dest.writeString(card_pro_price);
        dest.writeString(card_total_price);
    }
}
