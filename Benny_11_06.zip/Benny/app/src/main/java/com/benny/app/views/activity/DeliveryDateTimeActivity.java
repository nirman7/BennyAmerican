package com.benny.app.views.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.DateUtility;
import com.benny.app.views.adapter.DeliveryStoreAdapter;
import com.benny.app.viewsmodel.ProductModel;
import com.benny.app.viewsmodel.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DeliveryDateTimeActivity extends BaseFragmentActivity {

    @BindView(R.id.orderDateTV)
    TextView orderDateTV;
    @BindView(R.id.orderTimeTV)
    TextView orderTimeTV;

    private Activity activity;
    private UserModel userModel;
    private String type = "", orderType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_date_time);
        ButterKnife.bind(this);
        this.activity = DeliveryDateTimeActivity.this;
        this.userModel = new UserModel(activity);
        this.type = getIntent().getStringExtra("Type");
        this.orderType = getIntent().getStringExtra("Order_Type");

        orderDateTV.setText(DateUtility.getCurrentDate("EEEE dd MMMM yyyy"));
        if (orderType.equals("now")) {
            orderTimeTV.setText(DateUtility.getCurrentDate("hh:mm a"));
            orderTimeTV.setEnabled(false);
            orderDateTV.setEnabled(false);
        } else {
            if (mSharedStorage.getOrderDate().length() > 0) {
                orderDateTV.setText(DateUtility.convertDateFormatFromTo(mSharedStorage.getOrderDate(),
                        "yyyy-MM-dd", "EEEE dd MMMM yyyy"));
                orderTimeTV.setText(DateUtility.convertDateFormatFromTo(mSharedStorage.getOrderTime(),
                        "hh:mm:ss", "hh:mm a"));
                orderTimeTV.setEnabled(false);
                orderDateTV.setEnabled(false);
            }
        }
    }

    @OnClick({R.id.orderDateTV, R.id.orderTimeTV, R.id.submitBtn})
    public void onViewClicked(View view) {
        logConfig.hideKeyBoard(this);
        switch (view.getId()) {
            case R.id.orderDateTV:
                DateUtility.callDatePickerDialog(activity, orderDateTV, "EEEE dd MMMM yyyy");
                break;
            case R.id.orderTimeTV:
                DateUtility.callTimePickerDialog(activity, orderTimeTV, "hh:mm a");
                break;
            case R.id.submitBtn:
                callAddDeliveryDateTime();
                break;
        }
    }


    private void callAddDeliveryDateTime() {

        String orderDate = orderDateTV.getText().toString().trim();
        String orderTime = orderTimeTV.getText().toString().trim();

        if (orderDate.length() == 0) {
            logConfig.printToast(activity, "Please select order date.");
        } else if (orderTime.length() == 0) {
            logConfig.printToast(activity, "Please select order time.");
        } else {
            if (type.equals("home")) {
                callActivity();
            } else {
                //{"action":"place_order","user_id":"2","product_id":"1","cart_id":"1","total_price":"120",
                // "total_quantity":"20","tax_price":"100","order_type":"online"}
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("action", "place_order");
                    jsonObject.put("user_id", userModel.getUid());
                    jsonObject.put("user_type", WebUrls.USER);
                    jsonObject.put("order_date", DateUtility.convertDateFormatFromTo(orderDate,
                            "EEEE dd MMMM yyyy", "yyyy-MM-dd"));
                    jsonObject.put("order_time", DateUtility.convertDateFormatFromTo(orderTime,
                            "hh:mm a", "hh:mm:ss"));
                    jsonObject.put("cart_id", "");
                    jsonObject.put("product_id", "");
                    jsonObject.put("total_price", "");
                    jsonObject.put("total_quantity", "");
                    jsonObject.put("tax_price", "");
                    jsonObject.put("order_type","cash");

                    logConfig.printP("place_order jsonObject ", jsonObject.toString());

                    NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, jsonObject,
                            new ServiceResponse() {
                                @Override
                                public void requestResponse(String result) {
                                    logConfig.printP("place_order response ", result);
                                    parseResponse(result);
                                }
                            });
                    mNetworkApiCall.call();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void parseResponse(String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("true")) {
                //JSONObject jsonObject = jsonResponse.getJSONArray("data").getJSONObject(0);
                callActivity();
            } else {
                logConfig.printToast(this, message);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void callActivity() {

        if (type.equals("home")) {
            mSharedStorage.setOrderDate(DateUtility.convertDateFormatFromTo(orderDateTV.getText().toString(),
                    "EEEE dd MMMM yyyy", "yyyy-MM-dd"));
            mSharedStorage.setOrderTime(DateUtility.convertDateFormatFromTo(orderTimeTV.getText().toString(),
                    "hh:mm a", "hh:mm:ss"));
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
            finishAffinity();
        } else {
            logConfig.printToast(this, "Order Successfully.");
            finish();
        }
    }

}