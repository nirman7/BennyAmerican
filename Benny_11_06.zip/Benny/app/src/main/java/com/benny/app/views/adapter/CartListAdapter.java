package com.benny.app.views.adapter;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.WebUrls;
import com.benny.app.viewsmodel.AddToCartModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Jitendra Sharma on 01/06/2020.
 */
public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.ViewHolder> {

    private ArrayList<AddToCartModel> mList = new ArrayList<>();
    private FragmentActivity mActivity;
    private CallBacks mCallBacks;

    public CartListAdapter(FragmentActivity activity, CallBacks callBacks) {
        this.mActivity = activity;
        this.mCallBacks = callBacks;
    }

    public void setList(ArrayList<AddToCartModel> list) {
        this.mList = list;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_list_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        AddToCartModel mModel = mList.get(position);
        holder.productName.setText(mModel.getPro_name());
        holder.productDes.setText(Html.fromHtml(mModel.getPro_description()));
        holder.productPrice.setText("$ " + mModel.getPro_price());

        ConfigData.getInstance().setPicasoImageLoader(mActivity, holder.productImage,
                WebUrls.IMAGE_URL + mModel.getPro_img(), R.drawable.place_holder);

        if (mModel.getCard_pro_quantity() != null) {
            int cartCount = Integer.parseInt(mModel.getCard_pro_quantity());
            if (cartCount == 0) {
                holder.addToCartBtn.setVisibility(View.VISIBLE);
                holder.addDeleteBtn.setVisibility(View.GONE);
                holder.quantity.setText("");
            } else {
                holder.addToCartBtn.setVisibility(View.GONE);
                holder.addDeleteBtn.setVisibility(View.VISIBLE);
                holder.quantity.setText(mModel.getCard_pro_quantity());
            }
        } else {
            holder.addToCartBtn.setVisibility(View.VISIBLE);
            holder.addDeleteBtn.setVisibility(View.GONE);
        }

        holder.cartDeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBacks.deleteCart(mList.get(holder.getAdapterPosition()));
            }
        });


        holder.quantityMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddToCartModel model = mList.get(holder.getAdapterPosition());
                if (model.getCard_pro_quantity() != null && model.getCard_pro_quantity().length() > 0
                        && !model.getCard_pro_quantity().equals("0")) {
                    int itemCount = Integer.parseInt(model.getCard_pro_quantity());
                    int totPrice = Integer.parseInt(model.getCard_pro_price());
                    itemCount = itemCount-1;
                    model.setCard_pro_quantity("" + itemCount);
                    model.setCard_total_price("" + (itemCount * totPrice));
                } else {
                    model.setCard_total_price("0");
                    model.setCard_pro_quantity("0");
                }
                mCallBacks.minusToCart(model);
            }
        });
        holder.quantityPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddToCartModel model = mList.get(holder.getAdapterPosition());
                if (model.getCard_pro_quantity() != null && model.getCard_pro_quantity().length() > 0
                        && !model.getCard_pro_quantity().equals("0")) {
                    int itemCount = Integer.parseInt(model.getCard_pro_quantity());
                    int totPrice = Integer.parseInt(model.getCard_pro_price());
                    itemCount = 1+itemCount;
                    model.setCard_pro_quantity("" + itemCount);
                    model.setCard_total_price("" + (itemCount * totPrice));
                } else {
                    model.setCard_total_price("0");
                    model.setCard_pro_quantity("0");
                }
                mCallBacks.plusToCart(model);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }


    public interface CallBacks {
        void deleteCart(AddToCartModel model);

        void addToCart(AddToCartModel model);

        void plusToCart(AddToCartModel model);

        void minusToCart(AddToCartModel model);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.productImage)
        ImageView productImage;
        @BindView(R.id.product_name)
        TextView productName;
        @BindView(R.id.cart_delete_btn)
        ImageView cartDeleteBtn;
        @BindView(R.id.product_des)
        TextView productDes;
        @BindView(R.id.product_price)
        TextView productPrice;
        @BindView(R.id.addToCartBtn)
        Button addToCartBtn;
        @BindView(R.id.quantity_minus_btn)
        ImageView quantityMinus;
        @BindView(R.id.quantity_btn)
        TextView quantity;
        @BindView(R.id.quantity_plus_btn)
        ImageView quantityPlus;
        @BindView(R.id.addDeleteLayout)
        LinearLayout addDeleteBtn;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}