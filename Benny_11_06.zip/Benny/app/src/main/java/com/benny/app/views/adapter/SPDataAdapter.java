package com.benny.app.views.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.benny.app.R;
import com.benny.app.services.util.Constant;
import com.benny.app.viewsmodel.SPDataModel;
import java.util.List;

/**
 * Created  on 18/04/2020.
 * @author Jitendra Sharma
 */
public class SPDataAdapter extends ArrayAdapter<SPDataModel> {
    // Your sent context
    private Context context;
    // Your custom values for the spinner (User)
    private List<SPDataModel> values;

    public SPDataAdapter(Context context, int textViewResourceId, List<SPDataModel> values) {
        super(context, textViewResourceId, values);
        this.context = context;
        this.values = values;
    }

    public int getCount() {
        return values.size();
    }

    public SPDataModel getItem(int position) {
        return values.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    // This is for the "passive" state of the spinner
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // I created a dynamic TextView here, but you can reference your own  custom layout for each spinner item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_spinner_item, parent, false);
        TextView label = (TextView) view.findViewById(R.id.text1);
        Typeface face = Typeface.createFromAsset(getContext().getAssets(), Constant.APP_FONT_NAME);
        label.setTypeface(face);
        label.setText(values.get(position).getName());

        // And finally return your dynamic (or custom) view for each spinner item
        return view;
    }

    // And here is when the "chooser" is popped up
    // Normally is the same view, but you can customize it if you want
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_spinner_item, parent, false);
        TextView label = (TextView) view.findViewById(R.id.text1);
        Typeface face = Typeface.createFromAsset(getContext().getAssets(), Constant.APP_FONT_NAME);
        label.setTypeface(face);
        label.setText(values.get(position).getName());

        return view;
    }

}
