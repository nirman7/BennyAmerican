package com.benny.app.services.config;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.benny.app.R;
import com.benny.app.services.util.RoundedTransformation;
import com.benny.app.services.util.ScalingUtilities;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DecimalFormat;

/**
 * Created by user on 18/04/2020.
 */

public class ConfigData {

    private static ConfigData mConfigData;
    public static String registrationId;

    private ConfigData() {
    }

    public static ConfigData getInstance() {
        if (mConfigData == null) {
            mConfigData = new ConfigData();
        }
        return mConfigData;
    }



    public void displayAlert(final Activity mActivity, String message, final Boolean action) {

        final Dialog dialog = new Dialog(mActivity, android.R.style.Theme_Panel);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alert_with_callback);
        dialog.setCancelable(false);
        WindowManager.LayoutParams wmlp = dialog.getWindow().getAttributes();
        wmlp.gravity = Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL;
        wmlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        wmlp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(wmlp);

//        TextView txtTitle = (TextView) dialog.findViewById(R.id.alertTitle);
//        txtTitle.setText("Alert!");

        TextView txtSms = (TextView) dialog.findViewById(R.id.txt_alert_message);
        txtSms.setText(message);

        Button btnOk = (Button) dialog.findViewById(R.id.btn_alert_ok);
        btnOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (action) {
                    mActivity.finish();
                }
                dialog.dismiss();
            }
        });

        if (!dialog.isShowing())
            dialog.show();
    }


    public int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // should never happen
            throw new RuntimeException("Could not get package name: " + e);
        }
    }

    public static float convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return px;
    }

    public String getDeviceId(Activity mActivity) {

        String android_id = "";
        android_id = Settings.Secure.getString(mActivity.getContentResolver(), Settings.Secure.ANDROID_ID);

        return android_id;
    }

    public void showAlertDialogWithYesNoCallBack(Context context, String title,
                                                 String message, Boolean isCancelable, String positiveButtonTxt,
                                                 String negativeButtonTxt, final DialogCallBackAlert callback) {

        AlertDialog alertDialog = new AlertDialog.Builder(context, R.style.MyDialogTheme).create();
        alertDialog.setCancelable(isCancelable);
        alertDialog.setCanceledOnTouchOutside(isCancelable);

        // Setting Dialog Title
        alertDialog.setTitle(title);
        // Setting Dialog Message
        alertDialog.setMessage(message);

        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,
                positiveButtonTxt, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        callback.dialogCallBackPositive(dialog);
                    }
                });
        alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE,
                negativeButtonTxt, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        callback.dialogCallBackNegative(dialog);
                    }
                });
        alertDialog.show();
    }

    public interface DialogCallBackAlert {
        public void dialogCallBackPositive(DialogInterface dialog);

        public void dialogCallBackNegative(DialogInterface dialog);
    }


    public String decodeFile(String path, int DESIREDWIDTH, int DESIREDHEIGHT) {
        String strMyImagePath = null;
        Bitmap scaledBitmap = null;

        try {
            // Part 1: Decode image
            Bitmap unscaledBitmap = ScalingUtilities.decodeFile(path, DESIREDWIDTH,
                    DESIREDHEIGHT, ScalingUtilities.ScalingLogic.FIT);

            if (!(unscaledBitmap.getWidth() <= DESIREDWIDTH && unscaledBitmap.getHeight() <= DESIREDHEIGHT)) {
                // Part 2: Scale image
                scaledBitmap = ScalingUtilities.createScaledBitmap(unscaledBitmap, DESIREDWIDTH,
                        DESIREDHEIGHT, ScalingUtilities.ScalingLogic.FIT);
            } else {
                unscaledBitmap.recycle();
                return path;
            }

            // Store to tmp file

            String extr = Environment.getExternalStorageDirectory().toString();
            File mFolder = new File(extr + "/Kickon");
            if (!mFolder.exists()) {
                mFolder.mkdir();
            }

            String s = "agrigold_" + System.currentTimeMillis() + ".jpg";

            File f = new File(mFolder.getAbsolutePath(), s);

            strMyImagePath = f.getAbsolutePath();
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(f);
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                fos.flush();
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

            scaledBitmap.recycle();
        } catch (Throwable e) {
            e.printStackTrace();
        }

        if (strMyImagePath == null || !new File(strMyImagePath).exists()) {
            return path;
        } else {
            return strMyImagePath;
        }
    }

    public void loadImage(final Context context, final String imagePath,
                          final ImageView view, int ratioImg, int defaultImg) {
        Picasso.get()
                .load(imagePath)
                .error(defaultImg)
                .placeholder(defaultImg)
                .resize(ratioImg, ratioImg).centerCrop()
                .noFade()
                .into(view);

    }

    public void setPicasoImageLoaderRounded(Activity mActivity, ImageView imgView, String imagePath, int defaultImage) {

        Picasso.get()
                .load(imagePath)
                .placeholder(defaultImage)
                .transform(new RoundedTransformation(mActivity, R.color.black_color))//rounded, rounded))
                .error(defaultImage)
                .resize(500, 500)
                .into(imgView);
    }

    public void setPicasoImageLoader(final Activity mActivity, final ImageView imgView, final String imagePath, final int defaultImage) {

        Picasso.get()
                .load(imagePath)
                .placeholder(defaultImage)
                .error(defaultImage)
                .into(imgView);

    }


    public void setPicasoImageLoader(final Context mActivity, final ImageView imgView, final String imagePath, final int defaultImage) {

        Picasso.get()
                .load(imagePath)
                .placeholder(defaultImage)
                .error(defaultImage)
                .into(imgView);

    }

    public static double twoDigitDecimal(double value) {
        DecimalFormat df = new DecimalFormat("#.0");
        String angleFormated = df.format(value);
        double changeValue = Double.parseDouble(angleFormated);
        return changeValue;
    }

    public static int getSeekBarThumbPosX(SeekBar seekBar) {
        int posX;
        if (Build.VERSION.SDK_INT >= 16) {
            posX = seekBar.getThumb().getBounds().centerX();
        } else {
            int left = seekBar.getLeft() + seekBar.getPaddingLeft();
            int right = seekBar.getRight() - seekBar.getPaddingRight();
            float width = (float) (seekBar.getProgress() * (right - left)) / seekBar.getMax();
            posX = Math.round(width) + seekBar.getThumbOffset();
        }
        return posX;
    }

}
