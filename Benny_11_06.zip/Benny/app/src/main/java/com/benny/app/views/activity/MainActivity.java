package com.benny.app.views.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.dialog.ForgotPasswordDialog;
import com.benny.app.views.dialog.LoginDialog;
import com.benny.app.views.dialog.SignupDialog;
import com.benny.app.viewsmodel.UserModel;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends BaseFragmentActivity {

    private String TAG = "MainActivity ";
    private Activity mActivity;
    private UserModel userModel;
    private String selectType = "";
    private GoogleSignInClient mGoogleSignInClient;
    private FirebaseAuth mAuth;
    private CallbackManager mCallbackManager;
    private static final int RC_SIGN_IN = 9001;
    private ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseApp.initializeApp(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mActivity = MainActivity.this;
        this.userModel = new UserModel(mActivity);
        FacebookSdk.sdkInitialize(getApplicationContext());
        ButterKnife.bind(this);
        // Initialize FireBase Auth
        this.mAuth = FirebaseAuth.getInstance();

        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                // .requestIdToken(getResources().getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        //callFacebook();
    }

    @OnClick({R.id.layoutLogin, R.id.layoutDelivery, R.id.layoutPickup})//R.id.loginBtn,
    public void onViewClicked(View view) {
        logConfig.hideKeyBoard(this);
        Intent mIntent = null;
        switch (view.getId()) {
            case R.id.layoutLogin:
                selectType = "login";
                showLoginAlert();
                break;
            case R.id.layoutDelivery:
                logConfig.printToast(mActivity, "Currently providing only pickup order.");
//                if(userModel.getUid().length()>0) {
//                    Intent intent1 = new Intent(this, SelectDeliveryActivity.class);
//                    intent1.putExtra("Type", "home");
//                    startActivity(intent1);
//                } else {
//                    selectType = "delivery";
//                    showLoginAlert();
//                }
                break;
            case R.id.layoutPickup:
                if(userModel.getUid().length()>0) {
                    Intent intent = new Intent(this, SelectRestaurantActivity.class);
                    startActivity(intent);
                } else {
                    selectType = "pickup";
                    showLoginAlert();
                }
                break;
        }
    }

    private void showSignUpAlert() {

        SignupDialog dialog = new SignupDialog();
        dialog.setParameters(mActivity, new SignupDialog.SubmitCallback() {
            @Override
            public void callBack(JSONObject mJsonObject, String type) {
                if (type.equals("login")) {
                    dialog.dismiss();
                    showLoginAlert();
                } else if (type.equals("google")) {
                    dialog.dismiss();
                    signIn();
                } else {
                    callRegistrationRequest(dialog, mJsonObject);
                }
            }

            @Override
            public void callBackSocial(LoginButton loginButton, String type) {
                dialog.dismiss();
                callFacebook(loginButton);
            }
        });
        dialog.show(getSupportFragmentManager(), "Login");
    }

    private void callRegistrationRequest(SignupDialog dialog, JSONObject mJsonObject) {

        try {
            logConfig.printP("Signup mJsonObject: ", mJsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, mJsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            logConfig.printP("Signup response ", result);
                            parseRegistration(dialog, result);
                        }
                    });
            mNetworkApiCall.call();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void parseRegistration(SignupDialog dialog, String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("true")) {
                JSONObject jsonObject = jsonResponse.getJSONArray("data").getJSONObject(0);
                UserModel userModel = new UserModel(jsonObject);
                userModel.persist(mActivity);
                mSharedStorage.setLoginStatus(true);
                dialog.dismiss();
                callActivity();
            } else {
                logConfig.printToast(this, message);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showLoginAlert() {

        LoginDialog loginDialog = new LoginDialog();
        loginDialog.setParameters(mActivity, new LoginDialog.SubmitCallback() {
            @Override
            public void callBack(String email, String password, String type) {
                if (type.equals("forgot")) {
                    loginDialog.dismiss();
                    showForgotPasswordAlert();
                } else if (type.equals("signup")) {
                    loginDialog.dismiss();
                    showSignUpAlert();
                } else if (type.equals("login")) {
                    callLoginServiceRequest(loginDialog, email, password);
                } else if (type.equals("google")) {
                    loginDialog.dismiss();
                    signIn();
                } else {
                    loginDialog.dismiss();
                }
            }

            @Override
            public void callBackSocial(LoginButton loginButton, String type) {
                loginDialog.dismiss();
                callFacebook(loginButton);
            }
        });
        loginDialog.show(getSupportFragmentManager(), "Login");
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }


    private void callLoginServiceRequest(LoginDialog dialog, String email, String password) {
        //{"action":"user_login","user_email":"r@gmail.com","user_password":"123456"}
        try {
            JSONObject mJsonObject = new JSONObject();
            mJsonObject.put("action", "user_login");
            mJsonObject.put("user_email", email);
            mJsonObject.put("user_password", password);
            mJsonObject.put("user_type", WebUrls.USER);
            mJsonObject.put("device_token", mSharedStorage.getDeviceToken());
            mJsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("login_user mJsonObject: ", mJsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, mJsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            logConfig.printP("login_user response ", result);
                            parseLoginResponse(dialog, result);
                        }
                    });
            mNetworkApiCall.call();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseLoginResponse(LoginDialog dialog, String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("true")) {
                JSONObject jsonObject = jsonResponse.getJSONArray("data").getJSONObject(0);
                UserModel userModel = new UserModel(jsonObject);
                userModel.persist(mActivity);
                mSharedStorage.setLoginStatus(true);
                if(dialog != null) {
                    dialog.dismiss();
                }
                callActivity();
            } else {
                logConfig.printToast(this, message);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showForgotPasswordAlert() {

        ForgotPasswordDialog dialog = new ForgotPasswordDialog();
        dialog.setParameters(mActivity, new ForgotPasswordDialog.SubmitCallback() {
            @Override
            public void callBack(String email, String type) {
                if (type.equals("forgot")) {
                    callForgotServiceRequest(dialog, email);
                }
            }
        });
        dialog.show(getSupportFragmentManager(), "Login");
    }

    private void callForgotServiceRequest(ForgotPasswordDialog dialog, String email) {

        try {
            JSONObject mJsonObject = new JSONObject();
            mJsonObject.put("action", "forgot_password");
            mJsonObject.put("email", email);
            mJsonObject.put("user_type", WebUrls.USER);
            mJsonObject.put("device_token", mSharedStorage.getDeviceToken());
            mJsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("login_user mJsonObject: ", mJsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, mJsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            logConfig.printP("login_user response ", result);
                            parseForgotResponse(dialog, result);
                        }
                    });
            mNetworkApiCall.call();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseForgotResponse(ForgotPasswordDialog dialog, String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("true")) {
                dialog.dismiss();
                logConfig.printToast(this, message);
            } else {
                logConfig.printToast(this, message);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void callActivity() {

        if(selectType.equals("delivery")) {
            Intent intent1 = new Intent(this, SelectDeliveryActivity.class);
            intent1.putExtra("Type", "home");
            startActivity(intent1);
        } else if(selectType.equals("pickup")) {
            Intent intent1 = new Intent(this, SelectRestaurantActivity.class);
            startActivity(intent1);
        } else {
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
            finishAffinity();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                fireBaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w("Login", "Google sign in failed", e);
                // ...
            }
        } else {
            // Pass the activity result back to the Facebook SDK
            mCallbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }

    // [START auth_with_google]
    private void fireBaseAuthWithGoogle(GoogleSignInAccount acct) {
        logConfig.printP(TAG, "firebaseAuthWithGoogle:" + acct.getId());
        // [START_EXCLUDE silent]
        showProgressDialog();
        // [END_EXCLUDE]
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user, "GM");
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            //logConfig.printToast(mActivity, "Authentication Failed.");
                            updateUI(null, "GM");
                        }

                        // [START_EXCLUDE]
                        hideProgressDialog();
                        // [END_EXCLUDE]
                    }
                });
    }

    private void callFacebook(LoginButton loginButton) {

        // Initialize Facebook Login button
        logConfig.printP(TAG, " facebook:login");
        //mAuth.signOut();
        mCallbackManager = CallbackManager.Factory.create();
        loginButton.setReadPermissions("email", "public_profile");
        loginButton.registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                logConfig.printP(TAG, " facebook:onSuccess:" + loginResult);
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                logConfig.printP(TAG, " facebook:onCancel");
                // ...
            }

            @Override
            public void onError(FacebookException error) {
                logConfig.printP(TAG, " facebook:onError " + error);
                // ...
            }
        });
    }

    private void handleFacebookAccessToken(AccessToken token) {

        logConfig.printP(TAG, " handleFacebookAccessToken:" + token);
        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(credential).addOnCompleteListener(this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            logConfig.printP(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            updateUI(user, "FB");
                        } else {
                            // If sign in fails, display a message to the user.
                            logConfig.printP(TAG, "signInWithCredential:failure " + task.getException());
                            //logConfig.printToast(mActivity, "Authentication failed.");
                            updateUI(null, "FB");
                        }

                        // ...
                    }
                });
    }

    private void showProgressDialog() {
        SpannableString spannableString = new SpannableString("Loading...");
        spannableString.setSpan(new ForegroundColorSpan(Color.GRAY), 0, spannableString.length(), 0);
        pDialog = new ProgressDialog(mActivity);
        pDialog.setMessage(spannableString);
        pDialog.setCancelable(false);
        pDialog.show();
    }

    private void hideProgressDialog() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
        }

    }
    // [END auth_with_google]


    private void updateUI(FirebaseUser user, String type) {
        hideProgressDialog();
        if (user != null) {
            String socialId = user.getUid();
            String name = user.getDisplayName();
            String email = user.getEmail();
            String number = user.getPhoneNumber();
            String image = user.getPhotoUrl().toString();
            logConfig.printP("updateUI ", "socialId:" + socialId + " name:" + name
                    + " email:" + email + " number:" + number + " image:" + image);
            loginWithSocial(type, socialId, name, email, number, image);
        } else {
            logConfig.printToast(mActivity, "Google login field, Please try again.");
        }
    }

    private void loginWithSocial(String type, String socialId, String name, String email, String mobile_no, String image) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "social_login");
            jsonObject.put("social_id", socialId);
            jsonObject.put("user_name", name);
            jsonObject.put("email", email);
            jsonObject.put("mobile_no", mobile_no);
            jsonObject.put("image", image);
            jsonObject.put("login_type", type);
            jsonObject.put("device_id", configData.getDeviceId(this));
            jsonObject.put("device_token", mSharedStorage.getDeviceToken());
            jsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("social_login jsonObject: ", jsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, jsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            logConfig.printP("social_login response: ", result);
                            socialSignOut();
                            parseLoginResponse(null, result);
                        }
                    });
            mNetworkApiCall.call();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void socialSignOut() {
        // Firebase sign out
        mAuth.signOut();
    }

}