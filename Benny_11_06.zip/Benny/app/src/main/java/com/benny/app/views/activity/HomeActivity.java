package com.benny.app.views.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.services.config.SharedStorage;
import com.benny.app.services.config.WebUrls;
import com.benny.app.views.adapter.SliderListAdapter;
import com.benny.app.views.fragment.GalleryFragment;
import com.benny.app.views.fragment.HomeFragment;
import com.benny.app.views.fragment.MyOrdersFragment;
import com.benny.app.viewsmodel.SliderModel;
import com.benny.app.viewsmodel.UserModel;
import com.google.android.material.navigation.NavigationView;
import com.benny.app.BaseAppCompatActivity;
import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.views.fragment.ProfileDetailFragment;
import com.benny.app.views.fragment.SettingsFragment;
import com.benny.app.views.header.HeaderLayout;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class HomeActivity extends BaseAppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawer;
    private NavigationView navigationView;
    private Activity mActivity;
    private View mHeaderLayout;
    private SliderListAdapter sliderListAdapter;
    private ArrayList<SliderModel> mMenuList = new ArrayList<>();
    private UserModel userModel;
    private MenuItem menuItem;
    private BroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        this.mActivity = this;
        this.userModel = new UserModel(mActivity);

        setViews();
        switchFragment(0, getResources().getString(R.string.str_home));

        //callServiceClass();
    }

    private void setViews() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getString(R.string.str_all_categories));
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        mHeaderLayout = findViewById(R.id.headerBar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        toggle.setDrawerIndicatorEnabled(false);
        toggle.setHomeAsUpIndicator(R.drawable.ic_menu);
        toggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawer.isDrawerVisible(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else {
                    drawer.openDrawer(GravityCompat.START);
                }
            }
        });

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);    //For icon color of menu

        View view = navigationView.getHeaderView(0);
        ImageView facebookBtn = view.findViewById(R.id.facebookBtn);
        facebookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(WebUrls.FACEBOOK_URL));
                startActivity(intent);
            }
        });
        ImageView googleBtn = view.findViewById(R.id.googleBtn);
        googleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(WebUrls.GOOGLE_URL));
                startActivity(intent);
            }
        });
        ImageView twitterBtn = view.findViewById(R.id.twitterBtn);
        twitterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(WebUrls.TWITTER_URL));
                startActivity(intent);
            }
        });


        TextView userNameTV = view.findViewById(R.id.userNameTV);
        userNameTV.setText("Hi, " + userModel.getUser_fname() + " " + userModel.getUser_lname());
        RecyclerView recyclerViewSlider = view.findViewById(R.id.recyclerViewSlider);

        final LinearLayoutManager manager = new LinearLayoutManager(mActivity);
        recyclerViewSlider.setLayoutManager(manager);
        sliderListAdapter = new SliderListAdapter(mActivity, new SliderListAdapter.AdapterCallBack() {
            @Override
            public void itemClickListener(SliderModel model, String type) {
                onItemClicked(model.getId());
            }
        });
        recyclerViewSlider.setAdapter(sliderListAdapter);
        addItems();

        IntentFilter intentFilter = new IntentFilter(WebUrls.ACTION_CART_COUNT);
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(menuItem != null) {
                    menuItem.setIcon(buildCounterDrawable(sharedStorage.getCartCount(), R.drawable.ic_cart));
                }
            }
        };
        registerReceiver(broadcastReceiver, intentFilter);

    }

    private void onItemClicked(String id) {
        switch (id) {
            /** Handle the DashBoard action */
            case "1":
                switchFragment(0, getResources().getString(R.string.str_home));
                break;
            case "2":
                switchFragment(1, getResources().getString(R.string.str_my_orders));
                break;
            case "3":
                switchFragment(1, getResources().getString(R.string.str_gallery));
                break;
            case "4":
                switchFragment(2, getResources().getString(R.string.str_about_us));
                break;
            case "5":
                switchFragment(3, getResources().getString(R.string.str_manage_profile));
                break;
            case "6":
                switchFragment(4, getResources().getString(R.string.str_terms_and_conditions));
                break;
            /** Handle the Logout action */
            case "7":
                configData.showAlertDialogWithYesNoCallBack(mActivity, getResources().getString(R.string.logout_alert),
                        getResources().getString(R.string.str_logout_msg), false,
                        getResources().getString(R.string.logout_alert_yes), getResources().getString(R.string.logout_alert_no),
                        new ConfigData.DialogCallBackAlert() {
                            @Override
                            public void dialogCallBackPositive(DialogInterface dialog) {
                                SharedStorage mSharedStorage = SharedStorage.getInstance(mActivity);
                                mSharedStorage.logoutBtnAction();
                                Intent intent = new Intent(mActivity, MainActivity.class);
                                startActivity(intent);
                                mActivity.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_left_exit);
                                mActivity.finish();
                            }

                            @Override
                            public void dialogCallBackNegative(DialogInterface dialog) {
                                dialog.dismiss();
                            }
                        });
                break;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void addItems() {

        try {
            mMenuList.clear();
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", "1");
            jsonObject.put("name", "Home");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_home);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "2");
            jsonObject.put("name", "My Orders");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_my_order);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "3");
            jsonObject.put("name", "Gallery");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_gallery);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "4");
            jsonObject.put("name", "About Us");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_about_us);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "5");
            jsonObject.put("name", "Manage Profile");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_user_login);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "6");
            jsonObject.put("name", "Terms & Conditions");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_terms_condition);
            jsonArray.put(jsonObject);

            jsonObject = new JSONObject();
            jsonObject.put("id", "7");
            jsonObject.put("name", "Log Out");
            jsonObject.put("count", "");
            jsonObject.put("image", R.drawable.ic_logout);
            jsonArray.put(jsonObject);

            Gson gson = new Gson();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                SliderModel model = gson.fromJson(jsonObject1.toString(), SliderModel.class);
                mMenuList.add(model);
            }
            sliderListAdapter.setList(mMenuList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        menuItem = menu.findItem(R.id.action_settings);
        menuItem.setIcon(buildCounterDrawable(sharedStorage.getCartCount(), R.drawable.ic_cart));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            //LogPrint.showToastMessage(this, "button was clicked");
            Intent intent = new Intent(mActivity, CartListActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        return true;
    }

    private void switchFragment(int position, String title) {

        BaseFragment mBaseFragment;
        FragmentManager mFragmentManager;
        FragmentTransaction mFragmentTransaction;
        Bundle data = new Bundle();
        data.putString("Title", title);
        switch (position) {
            case 0: // Dashboard
                mBaseFragment = HomeFragment.getInstance(new HeaderLayout(mHeaderLayout), false);
                if (mBaseFragment != null) {
                    mBaseFragment.setArguments(data);
                    mFragmentManager = getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.commit();
                }
                break;
            case 1: // My Orders
                mBaseFragment = MyOrdersFragment.getInstance(new HeaderLayout(mHeaderLayout), false);
                if (mBaseFragment != null) {
                    clearBackStack();
                    mBaseFragment.setArguments(data);
                    mFragmentManager = getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("MyOrdersFragment");
                    mFragmentTransaction.commit();
                }
                break;
            case 2: // Gallery
                mBaseFragment = GalleryFragment.getInstance(new HeaderLayout(mHeaderLayout), false);
                if (mBaseFragment != null) {
                    clearBackStack();
                    mBaseFragment.setArguments(data);
                    mFragmentManager = getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("GalleryFragment");
                    mFragmentTransaction.commit();
                }
                break;
            case 3: // About Us
                Intent intent = new Intent(mActivity, PrivacyAndTermsActivity.class);
                intent.putExtra("Type", "about");
                startActivity(intent);
                break;
            case 4: // Manage Profile
                mBaseFragment = ProfileDetailFragment.getInstance(new HeaderLayout(mHeaderLayout), false);
                if (mBaseFragment != null) {
                    clearBackStack();
                    mBaseFragment.setArguments(data);
                    mFragmentManager = getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("ProfileDetailFragment");
                    mFragmentTransaction.commit();
                }
                break;
            case 5: // Terms & Conditions
                Intent intent1 = new Intent(mActivity, PrivacyAndTermsActivity.class);
                intent1.putExtra("Type", "terms");
                startActivity(intent1);
                break;
            case 6: // Settings
//                mBaseFragment = SettingsFragment.getInstance(new HeaderLayout(mHeaderLayout), false);
//                if (mBaseFragment != null) {
//                    clearBackStack();
//                    mBaseFragment.setArguments(data);
//                    mFragmentManager = getSupportFragmentManager();
//                    mFragmentTransaction = mFragmentManager.beginTransaction();
//                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
//                    mFragmentTransaction.addToBackStack("SettingsFragment");
//                    mFragmentTransaction.commit();
//                }
                break;

        }
    }

    private void clearBackStack() {

        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            /*FragmentManager.BackStackEntry first = manager.getBackStackEntryAt(0);
            manager.popBackStack(first.getId(), FragmentManager.POP_BACK_STACK_INCLUSIVE);*/
            FragmentManager fragmentManager = getSupportFragmentManager();
            // this will clear the back stack and displays no animation on the screen
            fragmentManager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }

    }

    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {

            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else {
                configData.showAlertDialogWithYesNoCallBack(this, getResources().getString(R.string.str_alert), getResources().getString(R.string.str_are_you_sure_exit),
                        false, getResources().getString(R.string.logout_alert_yes), getResources().getString(R.string.logout_alert_no), new ConfigData.DialogCallBackAlert() {
                            @Override
                            public void dialogCallBackPositive(DialogInterface dialog) {
                                finish();
                                System.exit(0);
                                dialog.dismiss();
                                //System.exit(0);
                                //super.onBackPressed();
                            }

                            @Override
                            public void dialogCallBackNegative(DialogInterface dialog) {
                                dialog.dismiss();
                            }
                        });
            }
        }
    }

}
