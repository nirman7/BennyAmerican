package com.benny.app.views.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.viewpager.widget.PagerAdapter;

import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.WebUrls;
import com.benny.app.viewsmodel.SlideModel;

import java.util.ArrayList;

/**
 * Created by user on 02/06/2020.
 */
public abstract class ImagePagerAdapter extends PagerAdapter {

    private Activity mActivity;
    private LayoutInflater layoutInflater;
    private ArrayList<SlideModel> mList = new ArrayList<>();
    private ConfigData configData = ConfigData.getInstance();

    public ImagePagerAdapter(Activity mActivity) {
        this.mActivity = mActivity;
        this.layoutInflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setList(ArrayList<SlideModel> list) {
        mList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((RelativeLayout) object);
    }


    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View itemView = null;
        try {
            final SlideModel models = mList.get(position);
            itemView = layoutInflater.inflate(R.layout.slider_pager_item, container, false);
            ImageView imageView = (ImageView) itemView.findViewById(R.id.advBottomImageView);

            configData.setPicasoImageLoader(mActivity, imageView,
                    WebUrls.IMAGE_URL + models.getImg(), R.drawable.place_holder);

            container.addView(itemView);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!models.getCat_id().equals("0")) {
                        itemClick(mList.get(position));
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        try {
            container.removeView((LinearLayout) object);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public abstract void itemClick(SlideModel model);
}
