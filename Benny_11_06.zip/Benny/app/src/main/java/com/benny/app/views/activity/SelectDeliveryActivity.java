package com.benny.app.views.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.adapter.DeliveryStoreAdapter;
import com.benny.app.views.adapter.ProductsAdapter;
import com.benny.app.views.dialog.ForgotPasswordDialog;
import com.benny.app.views.dialog.LoginDialog;
import com.benny.app.views.dialog.SignupDialog;
import com.benny.app.viewsmodel.ProductModel;
import com.benny.app.viewsmodel.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SelectDeliveryActivity extends BaseFragmentActivity {

    @BindView(R.id.nowBtn)
    TextView nowBtn;
    @BindView(R.id.laterBtn)
    TextView laterBtn;
    @BindView(R.id.unitNumberEV)
    EditText unitNumberEV;
    @BindView(R.id.houseNumberEV)
    EditText houseNumberEV;
    @BindView(R.id.streetNameEV)
    EditText streetNameEV;
    @BindView(R.id.suberbEV)
    EditText suberbEV;
    @BindView(R.id.stateEV)
    EditText stateEV;
    @BindView(R.id.pinCodeEV)
    EditText pinCodeEV;

    private Activity activity;
    private UserModel userModel;
    private String type="", orderType = "now";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_delivery);
        this.activity = SelectDeliveryActivity.this;
        this.userModel = new UserModel(activity);
        this.type = getIntent().getStringExtra("Type");
        ButterKnife.bind(this);

        unitNumberEV.setText(userModel.getUser_unit_number());
        houseNumberEV.setText(userModel.getUser_house_number());
        streetNameEV.setText(userModel.getUser_street_name());
        suberbEV.setText(userModel.getUser_suberb());
        stateEV.setText(userModel.getUser_state());
        pinCodeEV.setText(userModel.getUser_pincode());
    }


    @OnClick({R.id.nowBtn, R.id.laterBtn, R.id.nextBtn})
    public void onViewClicked(View view) {
        logConfig.hideKeyBoard(this);
        Intent mIntent = null;
        switch (view.getId()) {
            case R.id.nowBtn:
                orderType = "now";
                nowBtn.setBackgroundResource(R.drawable.ic_red_btn_bg);
                laterBtn.setBackgroundResource(R.drawable.ic_later_border);
                break;
            case R.id.laterBtn:
                orderType = "later";
                nowBtn.setBackgroundResource(R.drawable.ic_now_border);
                laterBtn.setBackgroundResource(R.drawable.ic_red_btn_bg);
                break;
            case R.id.nextBtn:
                callAddDeliveryAddress();
                break;
        }
    }


    private void callAddDeliveryAddress() {

        String unitNumber = unitNumberEV.getText().toString().trim();
        String houseNumber = houseNumberEV.getText().toString().trim();
        String streetName = streetNameEV.getText().toString().trim();
        String suberb = suberbEV.getText().toString().trim();
        String state = stateEV.getText().toString().trim();
        String pinCode = pinCodeEV.getText().toString().trim();

        if (unitNumber.length() == 0) {
            logConfig.printToast(activity, "Enter unit number.");
        } else if (houseNumber.length() == 0) {
            logConfig.printToast(activity, "Enter house number.");
        } else if (streetName.length() == 0) {
            logConfig.printToast(activity, "Enter street name.");
        } else if (state.length() == 0) {
            logConfig.printToast(activity, "Enter your state name.");
        } else if (pinCode.length() == 0) {
            logConfig.printToast(activity, "Enter your pin code.");
        } else {
            callActivity();
//            try {
//                JSONObject mJsonObject = new JSONObject();
//                mJsonObject.put("action", "add_delivery_address");
//                mJsonObject.put("user_id",  userModel.getUid());
//                mJsonObject.put("user_type", WebUrls.USER);
//                mJsonObject.put("user_unit_number", unitNumber);
//                mJsonObject.put("user_house_number", houseNumber);
//                mJsonObject.put("user_street_name", streetName);
//                mJsonObject.put("user_suberb", suberb);
//                mJsonObject.put("user_state", state);
//                mJsonObject.put("user_pincode", pinCode);
//
//                logConfig.printP("add_delivery_address mJsonObject ", mJsonObject.toString());
//
//                NetworkApiCall mNetworkApiCall = new NetworkApiCall(this, mJsonObject,
//                        new ServiceResponse() {
//                            @Override
//                            public void requestResponse(String result) {
//                                logConfig.printP("add_delivery_address response ", result);
//                                parseResponse(result);
//                            }
//                        });
//                mNetworkApiCall.call();
//
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
        }
    }

    private void parseResponse(String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("true")) {
                JSONObject jsonObject = jsonResponse.getJSONArray("data").getJSONObject(0);
                callActivity();
            } else {
                logConfig.printToast(this, message);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void callActivity() {

        Intent intent = new Intent(this, DeliveryDateTimeActivity.class);
        intent.putExtra("Type",type);
        intent.putExtra("Order_Type", orderType);
        startActivity(intent);
    }

}