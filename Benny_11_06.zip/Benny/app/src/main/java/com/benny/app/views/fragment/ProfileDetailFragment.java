package com.benny.app.views.fragment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.SharedStorage;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.services.util.ImageFilePath;
import com.benny.app.services.util.MarshMallowPermission;
import com.benny.app.views.customview.CustomAutoCompTVNormal;
import com.benny.app.views.customview.CustomEditTextValidation;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created  on 18/04/2020.
 * @author Jitendra Sharma
 */
public class ProfileDetailFragment extends BaseFragment {

    @BindView(R.id.profilePicIV)
    ImageView profilePicIV;
    @BindView(R.id.firstNameEV)
    EditText firstNameEV;
    @BindView(R.id.lastNameEV)
    EditText lastNameEV;
    @BindView(R.id.emailEV)
    EditText emailEV;
    @BindView(R.id.mobileNoEV)
    EditText mobileNoEV;
    @BindView(R.id.addressTV)
    TextView addressTV;

    private HeaderLayout mHeaderLayout;
    private FragmentActivity mActivity;
    private View convertView;
    private Unbinder unbinder;
    private MarshMallowPermission marshMallowPermission;
    private String profileImg = "";
    private UserModel userModel;

    public static ProfileDetailFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        ProfileDetailFragment fragment = new ProfileDetailFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.convertView = inflater.inflate(R.layout.fragment_profile_detail, null);
        this.unbinder = ButterKnife.bind(this, convertView);

        try {
            String title = getArguments().getString("Title");
            this.mHeaderLayout.setHeaderValues(0, title, 0);
            this.mHeaderLayout.setListenerItI(null, null);
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return convertView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.mActivity = getActivity();
        this.userModel = new UserModel(mActivity);

        this.marshMallowPermission = new MarshMallowPermission(mActivity);
        if (!marshMallowPermission.checkPermissionAll()) {
            marshMallowPermission.requestPermissionForAll();
        }
        setUserDetail();
    }

    private void setUserDetail() {

        try {
            firstNameEV.setText(userModel.getUser_fname());
            lastNameEV.setText(userModel.getUser_lname());
            emailEV.setText(userModel.getUser_email());
            mobileNoEV.setText(userModel.getUser_mobile());
            String address = userModel.getUser_unit_number()+" "+userModel.getUser_house_number()
                    +" "+userModel.getUser_street_name()+" "+userModel.getUser_state()+" "+userModel.getUser_pincode();
            if (address.length() > 0 && !address.equalsIgnoreCase("null")) {
                addressTV.setText(address);
            } else {
                addressTV.setText("");
            }
            profileImg = userModel.getUser_image();
            configData.setPicasoImageLoaderRounded(mActivity, profilePicIV,
                    WebUrls.IMAGE_URL + profileImg, R.drawable.green_circle);
        } catch (Exception e) {
            //e.printStackTrace();
        }

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick({R.id.profilePicEdit, R.id.saveBtn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.profilePicEdit:
                if (!marshMallowPermission.checkPermissionForCamera()) {
                    marshMallowPermission.requestPermissionForAll();
                } else {
                    startActivityForResult(getPickImageChooserIntent(), 2020);
                }
                break;
            case R.id.saveBtn:
                //profileUpdate();
                break;
        }
    }


    private void profileUpdate() {

        final String firstName = firstNameEV.getText().toString().trim();
        final String lastName = lastNameEV.getText().toString().trim();
        final String email = emailEV.getText().toString().trim();
        final String mobileNo = mobileNoEV.getText().toString().trim();
        final String address = addressTV.getText().toString().trim();

        if (firstName.length() == 0) {
            logConfig.printToast(mActivity, "Enter your first name.");
        } else if (lastName.length() == 0) {
            logConfig.printToast(mActivity, "Enter your last name.");
        } else if (mobileNo.length() == 0) {
            logConfig.printToast(mActivity, "Enter mobile number.");
        } else if (mobileNo.length() < 10) {
            logConfig.printToast(mActivity, "Enter valid mobile number.");
        } else if (address.length() == 0) {
            logConfig.printToast(mActivity, "Enter your address.");
        } else {
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("action", "update_profile");
                jsonObject.put("user_id", userModel.getUid());
                jsonObject.put("user_fname", firstName);
                jsonObject.put("user_lname", lastName);
                jsonObject.put("user_email", email);
                jsonObject.put("user_mobile", mobileNo);
                jsonObject.put("user_address", address);
                jsonObject.put("profile_image", profileImg);
                jsonObject.put("latitude", Constant.CURR_LATITUDE);
                jsonObject.put("longitude", Constant.CURR_LATITUDE);

                logConfig.printP("update_profile jsonObject: ", jsonObject.toString());

                NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject,
                        new ServiceResponse() {
                            @Override
                            public void requestResponse(String result) {
                                logConfig.printP("update_profile result: ", result);
                                parseResponse(result);
                            }
                        });
                mNetworkApiCall.call();

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void parseResponse(String response) {

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");

            logConfig.printToast(mActivity, message);
            if (status.equals("true")) {
                JSONObject jsonObject = jsonResponse.getJSONArray("data").getJSONObject(0);
                UserModel userModel = new UserModel(jsonObject);
                userModel.persist(mActivity);
                assert getFragmentManager() != null;
                if (getFragmentManager().getBackStackEntryCount() > 0) {
                    getFragmentManager().popBackStack();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == Activity.RESULT_OK) {
                ImageFilePath mImageFilePath = new ImageFilePath(mActivity);
                if (mImageFilePath.getPickImageResultUri(data) != null) {
                    Uri picUri = mImageFilePath.getPickImageResultUri(data);
                    String picture = mImageFilePath.getPath(mActivity.getApplicationContext(), picUri);
                    picture = ImageFilePath.decodeFileUri(mActivity, picUri, picture, 700, 700);
                    logConfig.printP("onActivityResult picture = ", "" + picture);

                    setCaptureImageInFragment(picture);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setCaptureImageInFragment(String picture) {

        configData.setPicasoImageLoaderRounded(mActivity, profilePicIV, "file://" + picture, R.drawable.green_circle);

        uploadSingleImage(picture, new ServiceResponse() {
            @Override
            public void requestResponse(String picture) {
                profileImg = picture;
                logConfig.printV("setCaptureImage ", "profileImg:" + profileImg);
            }
        });
    }

}