package com.benny.app.views.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.indicator.CirclePageIndicator;
import com.benny.app.services.util.Constant;
import com.benny.app.views.activity.CartListActivity;
import com.benny.app.views.adapter.ImagePagerAdapter;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.ProductModel;
import com.benny.app.viewsmodel.SlideModel;
import com.benny.app.viewsmodel.UserModel;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Timer;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created by Jitendra Sharma on 02/06/2020.
 */
public class ProductDetailFragment extends BaseFragment {

    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.circle_page_indicator)
    CirclePageIndicator circlePageIndicator;
    @BindView(R.id.product_image)
    ImageView product_image;
    @BindView(R.id.productNameTV)
    TextView productNameTV;
    @BindView(R.id.termsTV)
    TextView termsTV;
    @BindView(R.id.productPriceTV)
    TextView productPriceTV;
    @BindView(R.id.addToCartBtn)
    Button addToCartBtn;
    @BindView(R.id.quantity_minus_btn)
    ImageView quantityMinus;
    @BindView(R.id.quantity_btn)
    TextView quantityBtn;
    @BindView(R.id.quantity_plus_btn)
    ImageView quantityPlus;
    @BindView(R.id.descriptionTV)
    TextView descriptionTV;

    private Unbinder unbinder;
    private HeaderLayout mHeaderLayout;
    private View convertView;
    private FragmentActivity mActivity;
    private UserModel userModel;
    private ProductModel mProduct;
    private int quantity = 0, totalPrice = 0;

    private ArrayList<SlideModel> mSliderList = new ArrayList<>();
    private ImagePagerAdapter imagePagerAdapter;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    private Handler handler;
    private Runnable runnable;
    private Timer swipeTimer;

    public static ProductDetailFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        ProductDetailFragment fragment = new ProductDetailFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.mActivity = getActivity();
        this.convertView = inflater.inflate(R.layout.fragment_product_detail, null);
        this.unbinder = ButterKnife.bind(this, convertView);

        return convertView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        this.userModel = new UserModel(mActivity);
        this.mProduct = getArguments().getParcelable("ProductModel");
        setData();
    }

    private void setData() {

        productNameTV.setText(mProduct.getPro_name());
        productPriceTV.setText("$" + mProduct.getPro_price());
        descriptionTV.setText(mProduct.getPro_description());

        String url = WebUrls.IMAGE_URL + mProduct.getPro_img();
        configData.setPicasoImageLoader(mActivity, product_image, url, R.drawable.place_holder);

        imagePagerAdapter = new ImagePagerAdapter(mActivity) {
            @Override
            public void itemClick(SlideModel model) {
//                Intent mIntent = new Intent(mActivity, ProductDetailActivity.class);
//                mIntent.putExtra("ProductModel", model);
//                startActivity(mIntent);
            }
        };
        viewPager.setAdapter(imagePagerAdapter);
        circlePageIndicator.setViewPager(viewPager);

        getCategoryList();
    }

    @OnClick({R.id.quantity_minus_btn, R.id.quantity_plus_btn, R.id.addToCartBtn,
            R.id.addToOrderBtn, R.id.addOnBtn, R.id.addFreeBtn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.quantity_minus_btn:
                if (quantity != 0) {
                    quantity = quantity - 1;
                    totalPrice = quantity * Integer.parseInt(mProduct.getPro_price());
                } else {
                    quantity = 0;
                    totalPrice = 0;
                }
                quantityBtn.setText("" + quantity);
                //deleteFromCart(mProduct, quantity, totPrice);
                break;
            case R.id.quantity_plus_btn:
                quantity = 1 + quantity;
                totalPrice = quantity * Integer.parseInt(mProduct.getPro_price());
                quantityBtn.setText("" + quantity);
                //addToCartAction(mProduct, quantity, totPrice);
                break;
            case R.id.addToCartBtn:
                if (quantity == 0 || totalPrice == 0) {
                    logConfig.printToast(mActivity, "Please add product then after order.");
                } else {
                    addToCartAction(mProduct, quantity, totalPrice);
                }
                break;
            case R.id.addToOrderBtn:
                Intent intent = new Intent(mActivity, CartListActivity.class);
                startActivity(intent);
                break;
            case R.id.addOnBtn:
                switchFragment(0, "add_on");
                break;
            case R.id.addFreeBtn:
                switchFragment(0, "free");
                break;
        }
    }


    private void addToCartAction(ProductModel model, int quantity, int totPrice) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "add_to_order");
            jsonObject.put("uid", userModel.getUid());
            jsonObject.put("pro_id", model.getPro_id());
            jsonObject.put("cat_id", model.getSub_id());
            jsonObject.put("sub_id", model.getSub_id());
            jsonObject.put("pro_price", model.getPro_price());
            jsonObject.put("pro_quantity", "" + quantity);
            jsonObject.put("total_price", "" + totPrice);

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    parseAddCart(result);
                }
            });
            mNetworkApiCall.call();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseAddCart(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");
            if (status.equalsIgnoreCase("true")) {
                logConfig.printToast(mActivity, message);
                int cartCount = sharedStorage.getCartCount();
                cartCount = cartCount + 1;
                sharedStorage.setCartCount(cartCount);
                Intent itAction = new Intent(WebUrls.ACTION_CART_COUNT);
                mActivity.sendBroadcast(itAction);
                quantity = 0;
                totalPrice = 0;
                quantityBtn.setText("" + quantity);
            } else {
                logConfig.printToast(mActivity, message);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getCategoryList() {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "slider_list");
            jsonObject.put("user_id", userModel.getUid());
            jsonObject.put("category_id", "0");

            logConfig.printV("slider_list ", "jsonObject: " + jsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    logConfig.printV("slider_list response: ", result);
                    parseCategoryList(result);
                }
            });
            mNetworkApiCall.callWithoutProgressDialog();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseCategoryList(String result) {

        try {
            JSONObject jsonObject = new JSONObject(result);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");
            mSliderList.clear();
            if (status) {
                Gson gson = new Gson();
                /// product images for top slider
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        SlideModel mProductModel = gson.fromJson(jsonArray.getJSONObject(i).toString(),
                                SlideModel.class);
                        mSliderList.add(mProductModel);
                    }
                    NUM_PAGES = mSliderList.size();
                    // advSlideAutomatically();
                }
            } else {
                logConfig.printToast(mActivity, message);
            }
            imagePagerAdapter.setList(mSliderList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    BaseFragment mBaseFragment = null;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;

    private void switchFragment(int position, String type) {
        Bundle mBundle = new Bundle();
        mBundle.putString("Title", "Add On Product");
        mBundle.putString("Type", type);
        switch (position) {
            case 0:
                mBaseFragment = AddOnFragment.getInstance(mHeaderLayout, false);
                if (mBaseFragment != null) {
                    mBaseFragment.setArguments(mBundle);
                    mFragmentManager = mActivity.getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("AddOnFragment");
                    mFragmentTransaction.commit();
                }
                break;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
