package com.benny.app.services.util;

/**
 * Created  on 18/04/2020.
 *
 * @author Jitendra Sharma
 */

public class Constant {
    public static final String APP_OTHER_NAME = "arizonia_regular.ttf";
    public static final String APP_FONT_NAME = "roboto_regular.ttf";
    public static final String APP_FONT_NAME_MED = "roboto_medium.ttf";
    public static final String APP_FONT_NAME_BOLD = "roboto_bold.ttf";

    public static final String DEVICE_TYPE="Android";
    public static double CURR_LATITUDE = 0.0;
    public static double CURR_LONGITUDE = 0.0;

    public static String ACTION_NOTIFICATION_PUSH;
}
