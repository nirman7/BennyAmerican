package com.benny.app.views.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.adapter.GalleryAdapter;
import com.benny.app.views.adapter.ProductsAdapter;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.CategoryModel;
import com.benny.app.viewsmodel.ProductModel;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Jitendra Sharma on 01/06/2020.
 */
public class GalleryFragment extends BaseFragment {

    @BindView(R.id.recyclerView_list)
    RecyclerView recyclerView;

    private View convertView;
    private Unbinder unbinder;
    private FragmentActivity mActivity;
    private HeaderLayout mHeaderLayout;
    private GalleryAdapter mAdapter;
    private ArrayList<ProductModel> galleryList = new ArrayList<>();

    public static GalleryFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        GalleryFragment fragment = new GalleryFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.convertView = inflater.inflate(R.layout.fragment_gallery, null);
        this.unbinder = ButterKnife.bind(this, convertView);

        String title = getArguments().getString("Title");
        this.mHeaderLayout.setHeaderValues(0, "logo", 0);
        this.mHeaderLayout.setListenerItI(null, null);

        return convertView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        this.mActivity = getActivity();

        setAdapter();
        getGalleryList();
    }

    private void setAdapter() {

        final GridLayoutManager manager = new GridLayoutManager(mActivity, 3);
        recyclerView.setLayoutManager(manager);
        mAdapter = new GalleryAdapter(mActivity, new GalleryAdapter.AdapterBtnCallBack() {
            @Override
            public void itemClickListener(ProductModel model, String type) {

            }
        });
        recyclerView.setAdapter(mAdapter);
    }


    private void getGalleryList() {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "get_restaurant_gallery");
            jsonObject.put("user_id", userModel.getUid());
            jsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("restaurant_gallery", "jsonObject: " + jsonObject.toString());

            NetworkApiCall service = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    logConfig.printP("restaurant_gallery", "result: " + result);
                    parseList(result);
                }
            });
            service.call();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void parseList(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");
            galleryList.clear();
            if (status.equalsIgnoreCase("true")) {
                JSONArray data = jsonObject.getJSONArray("data");
                Gson gson = new Gson();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject jsonObject1 = data.getJSONObject(i);
                    ProductModel model = gson.fromJson(jsonObject1.toString(), ProductModel.class);
                    galleryList.add(model);
                }
            } else {
                logConfig.printToast(mActivity, message);
            }
            mAdapter.setList(galleryList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
