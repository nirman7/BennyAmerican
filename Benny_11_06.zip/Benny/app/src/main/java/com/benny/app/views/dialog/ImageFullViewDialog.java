package com.benny.app.views.dialog;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.RelativeLayout;

import com.benny.app.R;
import com.benny.app.services.util.TouchImageView;
import com.benny.app.services.util.Utility;
import com.benny.app.services.config.WebUrls;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


/**
 * Created by Jitendra Sharma on 20/05/2020.
 */
public class ImageFullViewDialog extends DialogFragment {

    private RelativeLayout descriptionLayout;
    private TouchImageView touchImageView;
    private Unbinder unbinder;
    private Activity activity;
    private String mImage;
    private Utility utility;

    public ImageFullViewDialog() {
        // Required empty public constructor
    }

    public void setParameter(Activity activity, String image) {
        this.activity = activity;
        this.mImage = image;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getDialog().getWindow();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        utility = new Utility();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_image_full_view, container, false);
        unbinder = ButterKnife.bind(this, view);

        touchImageView = (TouchImageView) view.findViewById(R.id.item_image);
        final String imageUrl = WebUrls.IMAGE_URL + mImage;
        utility.loadImageLarge(activity, imageUrl, touchImageView, R.drawable.place_holder);

        descriptionLayout = (RelativeLayout) view.findViewById(R.id.descriptionLayout);
        descriptionLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        touchImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        return view;
    }


    @Override
    public void show(FragmentManager manager, String tag) {
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.CustomDialog);
        super.show(manager, tag);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick(R.id.submit_btn)
    public void onViewClicked() {
       dismiss();
    }
}
