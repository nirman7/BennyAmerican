package com.benny.app.views.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;

public class SplashActivity extends BaseFragmentActivity {

    private static final long SPLASH_TIME = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // call local update data method
                changeActivity();
            }
        }, SPLASH_TIME);

    }

    void changeActivity() {
        Intent mIntent = null;
        if (mSharedStorage.getLoginStatus()) {
            mIntent = new Intent(this, HomeActivity.class);
        } else {
            mIntent = new Intent(this, MainActivity.class);
        }
        startActivity(mIntent);
        finish();

    }

}
