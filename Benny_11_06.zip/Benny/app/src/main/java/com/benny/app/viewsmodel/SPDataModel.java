package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class SPDataModel implements Parcelable {
    public static final Creator<SPDataModel> CREATOR = new Creator<SPDataModel>() {
        @Override
        public SPDataModel createFromParcel(Parcel source) {
            SPDataModel var = new SPDataModel();
            var.id = source.readString();
            var.name = source.readString();

            return var;
        }

        @Override
        public SPDataModel[] newArray(int size) {
            return new SPDataModel[size];
        }
    };
    private String id;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.name);
    }

    @Override
    public int describeContents() {
        return 0;
    }


}
