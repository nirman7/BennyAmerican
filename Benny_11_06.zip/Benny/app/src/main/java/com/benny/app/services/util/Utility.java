package com.benny.app.services.util;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.Display;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;

import com.benny.app.R;
import com.squareup.picasso.Picasso;

/**
 * Created  on 18/04/2020.
 * @author Jitendra Sharma
 */
public class Utility {

    public void loadImage(final Context context, final String imagePath,
                          final ImageView view, int ratioImg, int defaultImg) {
        Picasso.get()
                .load(imagePath)
                .error(defaultImg)
                .placeholder(defaultImg)
                .resize(ratioImg, ratioImg).centerCrop()
                .noFade()
                .into(view);

    }

    public void loadImageLarge(final Context context, final String imagePath, final ImageView view, int defaultImg) {
        Picasso.get()
                .load(imagePath)
                .error(defaultImg)
                .placeholder(defaultImg)
                .noFade()
                .into(view);

    }

    public void setPicassoImageLoaderRounded(Activity mActivity, ImageView imgView, String imagePath, int defaultImage) {

        Picasso.get()
                .load(imagePath)
                .placeholder(defaultImage)
                .transform(new RoundedTransformation(mActivity, R.color.black_color))//rounded, rounded))
                .error(defaultImage)
                .resize(500, 500)
                .into(imgView);
    }

    public static int getScreenWidth(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        int pxWidth = outMetrics.widthPixels;
        return pxWidth;
    }

    public static int getScreenHeight(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        int pxHeight = outMetrics.heightPixels;
        return pxHeight;
    }

    public static void showAlertDialogWithYesNoCallBack(Context context, String title,
                                                        String message, Boolean isCancelable, String positiveButtonTxt,
                                                        String negativeButtonTxt, final DialogCallBackAlert callback) {

        AlertDialog alertDialog = new AlertDialog.Builder(context, R.style.MyDialogTheme).create();
        alertDialog.setCancelable(isCancelable);
        alertDialog.setCanceledOnTouchOutside(isCancelable);

        // Setting Dialog Title
        alertDialog.setTitle(title);
        // Setting Dialog Message
        alertDialog.setMessage(message);

        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,
                positiveButtonTxt, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        callback.dialogCallBackPositive(dialog);
                    }
                });
        alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE,
                negativeButtonTxt, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        callback.dialogCallBackNagative(dialog);
                    }
                });
        alertDialog.show();
    }

    public static void showAlertDialogCallBack(Context context, String title,
                                               String message, Boolean isCancelable, String positiveButtonTxt,
                                               final DialogCallBackAlert callback) {

        AlertDialog alertDialog = new AlertDialog.Builder(context, R.style.MyDialogTheme).create();
        alertDialog.setCancelable(isCancelable);
        alertDialog.setCanceledOnTouchOutside(isCancelable);

        // Setting Dialog Title
        alertDialog.setTitle(title);
        // Setting Dialog Message
        alertDialog.setMessage(message);

        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE,
                positiveButtonTxt, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        callback.dialogCallBackPositive(dialog);
                    }
                });
        alertDialog.show();
    }


    public interface DialogCallBackAlert {
        public void dialogCallBackPositive(DialogInterface dialog);

        public void dialogCallBackNagative(DialogInterface dialog);
    }

    public static float convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return px;
    }


}
