package com.benny.app.views.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.WebUrls;
import com.benny.app.viewsmodel.CategoryModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Jitendra Sharma on 28/04/2020.
 */
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ItemViewHolder> {

    public ArrayList<CategoryModel> mList = new ArrayList<>();
    private AdapterCallBack mCallBack;
    private FragmentActivity mActivity;
    private ConfigData configData = ConfigData.getInstance();

    public CategoryAdapter(FragmentActivity activity, AdapterCallBack callBack) {
        this.mActivity = activity;
        this.mCallBack = callBack;
    }

    public void setList(ArrayList mArray) {
        this.mList = mArray;
        notifyDataSetChanged();
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.category_list_item, parent, false);

        return new ItemViewHolder(itemView, new ItemViewHolder.RecyclerViewClickListener() {
            @Override
            public void onClick(View view, int position) {
                mCallBack.itemClickListener(mList.get(position));
            }
        });
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, final int position) {
        final CategoryModel model = mList.get(position);
        //holder.productIV.setImageResource(model.getImage());
        if (position % 2 == 0) {
            holder.productNameLeftTV.setText(model.getCategory_name());
            holder.productNameRightTV.setText("");
        } else {
            holder.productNameRightTV.setText(model.getCategory_name());
            holder.productNameLeftTV.setText("");
        }

        String url = WebUrls.IMAGE_URL + model.getImg();
        configData.setPicasoImageLoader(mActivity, holder.productIV, url, R.drawable.place_holder);

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.productIV)
        ImageView productIV;
        @BindView(R.id.productNameLeftTV)
        TextView productNameLeftTV;
        @BindView(R.id.productNameRightTV)
        TextView productNameRightTV;

        RecyclerViewClickListener mListener;

        ItemViewHolder(View view, RecyclerViewClickListener listener) {
            super(view);
            ButterKnife.bind(this, view);
            this.mListener = listener;
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v, getAdapterPosition());
        }

        public interface RecyclerViewClickListener {
            void onClick(View view, int position);
        }
    }

    public interface AdapterCallBack {
        void itemClickListener(CategoryModel model);
    }

}
