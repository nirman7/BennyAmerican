package com.benny.app.views.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.adapter.ProductsAdapter;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.CategoryModel;
import com.benny.app.viewsmodel.ProductModel;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by Jitendra Sharma on 01/06/2020.
 */
public class ProductsFragment extends BaseFragment {

    @BindView(R.id.recyclerView_list)
    RecyclerView recyclerView;
    @BindView(R.id.searchEV)
    EditText searchEV;
    @BindView(R.id.subCatNameTV)
    TextView subCatNameTV;

    private View convertView;
    private Unbinder unbinder;
    private FragmentActivity mActivity;
    private HeaderLayout mHeaderLayout;
    private ProductsAdapter mAdapter;
    private ArrayList<ProductModel> productList = new ArrayList<>();
    private String catId = "", subCatId="";

    public static ProductsFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        ProductsFragment fragment = new ProductsFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.convertView = inflater.inflate(R.layout.fragment_products, null);
        this.unbinder = ButterKnife.bind(this, convertView);

        String title = getArguments().getString("Title");
        this.mHeaderLayout.setHeaderValues(0, "logo", 0);
        this.mHeaderLayout.setListenerItI(null, null);

        return convertView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        this.mActivity = getActivity();
        CategoryModel categoryModel = getArguments().getParcelable("CategoryModel");
        this.catId = categoryModel.getCat_id();
        this.subCatId = categoryModel.getSub_id();
        subCatNameTV.setText(categoryModel.getSub_name());

        setAdapter();
        getProductList();
    }

    private void setAdapter() {

        final LinearLayoutManager manager = new LinearLayoutManager(mActivity);
        recyclerView.setLayoutManager(manager);
        mAdapter = new ProductsAdapter(mActivity, new ProductsAdapter.AdapterBtnCallBack() {
            @Override
            public void itemClickListener(ProductModel model, String type) {
                switchFragment(0, model);
            }
        });
        recyclerView.setAdapter(mAdapter);


        //to call a method whenever there is some change on the EditText
        searchEV.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //after the change calling the method and passing the search input
                filter(editable.toString());
            }
        });
    }

    private void filter(String text) {
        ArrayList<ProductModel> temp = new ArrayList();
        for (ProductModel d : productList) {
            //or use .equal(text) with you want equal match
            //use .toLowerCase() for better matches
            if (d.getPro_name().contains(text)) {
                temp.add(d);
            }
        }
        //update recyclerview
        mAdapter.setList(temp);
    }


    private void getProductList() {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "product_list");
            jsonObject.put("user_id", userModel.getUid());
            jsonObject.put("cat_id", catId);
            jsonObject.put("sub_id", subCatId);
            jsonObject.put("device_type", Constant.DEVICE_TYPE);

            logConfig.printP("product_list", "jsonObject: " + jsonObject.toString());

            NetworkApiCall service = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    logConfig.printP("product_list", "result: " + result);
                    parseList(result);
                }
            });
            service.call();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void parseList(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");
            productList.clear();
            if (status.equalsIgnoreCase("true")) {
                JSONArray data = jsonObject.getJSONArray("data");
                Gson gson = new Gson();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject jsonObject1 = data.getJSONObject(i);
                    ProductModel model = gson.fromJson(jsonObject1.toString(), ProductModel.class);
                    productList.add(model);
                }
            } else {
                logConfig.printToast(mActivity, message);
            }
            mAdapter.setList(productList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    BaseFragment mBaseFragment = null;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;

    private void switchFragment(int position, ProductModel model) {
        Bundle mBundle = new Bundle();
        mBundle.putString("Title", model.getPro_name());
        mBundle.putParcelable("ProductModel", model);
        switch (position) {
            case 0:
                mBaseFragment = ProductDetailFragment.getInstance(mHeaderLayout, false);
                if (mBaseFragment != null) {
                    mBaseFragment.setArguments(mBundle);
                    mFragmentManager = mActivity.getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("ProductDetailFragment");
                    mFragmentTransaction.commit();
                }
                break;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
