package com.benny.app.views.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.BaseAppCompatActivity;
import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.SharedStorage;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.views.adapter.CartListAdapter;
import com.benny.app.viewsmodel.AddToCartModel;
import com.benny.app.viewsmodel.UserModel;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created by Jitendra Sharma on 12/2/2018.
 */
public class CartListActivity extends BaseAppCompatActivity {

    @BindView(R.id.item_title)
    TextView itemTitle;
    @BindView(R.id.dash)
    TextView dash;
    @BindView(R.id.totalPrice)
    TextView totalPrice;
    @BindView(R.id.subcategoryList)
    RecyclerView recyclerViewCategory;
    @BindView(R.id.checkoutBtn)
    TextView checkoutBtn;

    private FragmentActivity mActivity;
    private CartListAdapter mAdapter;
    private ArrayList<AddToCartModel> mList = new ArrayList<>();
    private UserModel userModel;
    private Unbinder unbinder;
    private BroadcastReceiver receiver;
    private boolean isOrderStatusChanged = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_list);
        this.unbinder = ButterKnife.bind(this);
        this.mActivity = CartListActivity.this;
        this.userModel = new UserModel(mActivity);

        IntentFilter intentFilter = new IntentFilter(WebUrls.ACTION_ORDER_PLACE);
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                isOrderStatusChanged = true;
            }
        };
        registerReceiver(receiver, intentFilter);

        setHeader(R.drawable.ic_arrow_left, 0, "logo",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       finish();
                    }
                }, null);


        setUpView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isOrderStatusChanged) {
            isOrderStatusChanged = false;
            sharedStorage.setCartCount(0);
            Intent itAction = new Intent(WebUrls.ACTION_CART_COUNT);
            mActivity.sendBroadcast(itAction);
            getCartList();
        }
    }

    @OnClick(R.id.checkoutBtn)
    public void onViewClicked() {
        Intent intent = new Intent(this, DeliveryDateTimeActivity.class);
        intent.putExtra("Type","order");
        intent.putExtra("Order_Type","");
        startActivity(intent);
    }

    private void setUpView() {
        
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(mActivity);
        recyclerViewCategory.setLayoutManager(mLayoutManager);
        mAdapter = new CartListAdapter(mActivity, new CartListAdapter.CallBacks() {
            @Override
            public void deleteCart(AddToCartModel model) {
                alertDeleteConfirmation(model, "delete");
            }

            @Override
            public void addToCart(AddToCartModel model) {
                //addToCartAction(model);
            }

            @Override
            public void plusToCart(AddToCartModel model) {
                addToCartAction(model, "update");
            }

            @Override
            public void minusToCart(AddToCartModel model) {
                addToCartAction(model, "update");
            }
        });
        recyclerViewCategory.setAdapter(mAdapter);

        getCartList();
    }

    private void getCartList() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "card_detail");
            jsonObject.put("uid", userModel.getUid());

            logConfig.printP("getCartList ", "jsonObject: " + jsonObject.toString());

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            logConfig.printP("getCartList ", "result: " + result);
                            parseCartList(result);
                        }
                    });
            mNetworkApiCall.call();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseCartList(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");
            //String message = jsonObject.getString("message");
            mList.clear();
            if (status) {
                sharedStorage.setCartCount(0);
                JSONArray data = jsonObject.getJSONArray("data");
                Gson gson = new Gson();
                for (int i = 0; i < data.length(); i++) {
                    AddToCartModel model = gson.fromJson(data.getJSONObject(i).toString(), AddToCartModel.class);
                    mList.add(model);
                }
            } else {
                logConfig.printToast(mActivity, getResources().getString(R.string.str_data_not_found));
            }
            updateData();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void updateData() {

        double totalPriceAmount = 0;
        if (mList.size() > 1) {
            for (int i = 0; i < mList.size(); i++) {
                totalPriceAmount = totalPriceAmount + (Double.parseDouble(mList.get(i).getCard_pro_price())
                        * Double.parseDouble(mList.get(i).getCard_pro_quantity()));
            }
            itemTitle.setText(mList.size() + " " + getResources().getString(R.string.str_items));
        } else {
            if (mList.size() > 0) {
                totalPriceAmount = Double.parseDouble(mList.get(0).getCard_pro_price())
                        * Double.parseDouble(mList.get(0).getCard_pro_quantity());
            }
            itemTitle.setText(mList.size() + " " + getResources().getString(R.string.str_item));
        }

        totalPrice.setText("$"+totalPriceAmount);
        mAdapter.setList(mList);
    }

    private void addToCartAction(final AddToCartModel model, String type) {

       // {"action":"card_managment","uid":"2","card_id":"2","total_quanlity":"300","total_price":"123456","type":"update"}

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "card_managment");
            jsonObject.put("uid", userModel.getUid());
            jsonObject.put("pro_id", model.getPro_id());
            jsonObject.put("card_id", model.getCard_id());
            jsonObject.put("total_quanlity", model.getCard_pro_quantity());
            jsonObject.put("total_price", model.getCard_total_price());
            jsonObject.put("type", type);

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject,
                    new ServiceResponse() {
                        @Override
                        public void requestResponse(String result) {
                            parseAddCart(result, model);
                        }
                    });
            mNetworkApiCall.callWithoutProgressDialog();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseAddCart(String result, AddToCartModel model) {

        try {
            JSONObject jsonObject = new JSONObject(result);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");
            if (status) {
                //JSONObject data = jsonObject.getJSONArray("data").getJSONObject(0);
                for (int i = 0; i < mList.size(); i++) {
                    if (mList.get(i).getPro_id().equals(model.getPro_id())) {
                        mList.get(i).setCard_pro_quantity(model.getCard_pro_quantity());
                    }
                }

            } else {
                if (message.equals("Cart is Empty")) {
                    mList.remove(model);
                } else {
                    logConfig.printToast(mActivity, message);
                }
            }
            changeStatus();
            updateData();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void alertDeleteConfirmation(final AddToCartModel model, String type) {
        configData.showAlertDialogWithYesNoCallBack(mActivity, getResources().getString(R.string.str_alert),
                "Are you sure, Do you want to delete this item?", false,
                getResources().getString(R.string.logout_alert_yes), getResources().getString(R.string.logout_alert_no),
                new ConfigData.DialogCallBackAlert() {
                    @Override
                    public void dialogCallBackPositive(DialogInterface dialog) {
                        deleteCartItem(model, type);
                    }

                    @Override
                    public void dialogCallBackNegative(DialogInterface dialog) {
                        dialog.dismiss();
                    }
                });

    }

    private void deleteCartItem(final AddToCartModel model, String type) {

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "card_managment");
            jsonObject.put("uid", userModel.getUid());
            jsonObject.put("pro_id", model.getPro_id());
            jsonObject.put("card_id", model.getCard_id());
            jsonObject.put("total_quanlity", model.getCard_pro_quantity());
            jsonObject.put("total_price", model.getCard_total_price());
            jsonObject.put("type", type);

            NetworkApiCall mNetworkApiCall = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                @Override
                public void requestResponse(String result) {
                    parseDeleteCartItem(result, model);
                }
            });
            mNetworkApiCall.call();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseDeleteCartItem(String response, AddToCartModel model) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");
            if (status) {
                mList.remove(model);
            } else {
                logConfig.printToast(mActivity, message);
            }
            changeStatus();
            updateData();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
        unregisterReceiver(receiver);
    }


    public void changeStatus() {
        Intent intent = new Intent(WebUrls.ACTION_PRODUCT_STATUS);
        mActivity.sendBroadcast(intent);
    }


}