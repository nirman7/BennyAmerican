package com.benny.app.views.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.config.CheckNetwork;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.WebUrls;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Jitendra Sharma on 18/04/2020.
 *
 */
public class PrivacyAndTermsActivity extends BaseFragmentActivity {

    @BindView(R.id.webview)
    WebView webview;

    private ProgressDialog progressBar;
    private CheckNetwork mCheckNetwork;
    public String PROGRESS_DIALOG_TITLE = "Loading...";
    private String title = "", url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_and_terms);
        ButterKnife.bind(this);

        String type = getIntent().getStringExtra("Type");

        if (type.equals("about")) {
            title = getResources().getString(R.string.str_about_us);
            url = WebUrls.ABOUT_US_URL;
        } else if (type.equals("terms")) {
            title = getResources().getString(R.string.str_terms_and_conditions);
            url = WebUrls.TERMS_CONDITION_URL;
        } else {
            title = getResources().getString(R.string.str_privacy_policy);
            url = WebUrls.PRIVACY_POLICY_URL;
        }

        setHeader(R.drawable.ic_arrow_left, 0, title, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        }, null);

    }

    @Override
    public void onResume() {
        super.onResume();
        initComponent();
    }

    private void initComponent() {

        mCheckNetwork = new CheckNetwork(this);
        if (mCheckNetwork.isConnectingToInternet()) {
            webview.getSettings().setJavaScriptEnabled(true);
            progressBar = new ProgressDialog(this);
            progressBar.setCancelable(false);
            progressBar.setMessage(PROGRESS_DIALOG_TITLE);
            progressBar.show();
            webview.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    return true;
                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    if (progressBar.isShowing()) {
                        progressBar.dismiss();
                    }
                }

                @Override
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    displayAlert(
                            "Error:" + description, false);

                }
            });
            webview.loadUrl(url);

        } else {
            displayAlert(this.getResources().getString(R.string.connection_network), false);
        }
    }

    private void displayAlert(String message, final Boolean action) {
        ConfigData.getInstance().displayAlert(this, message, action);

    }


}
