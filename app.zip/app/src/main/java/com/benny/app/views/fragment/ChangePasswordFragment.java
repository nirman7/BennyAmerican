package com.benny.app.views.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;

import com.google.android.material.textfield.TextInputEditText;
import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.views.header.HeaderLayout;
import com.benny.app.viewsmodel.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created  on 18/04/2020.
 * @author Jitendra Sharma
 */
public class ChangePasswordFragment extends BaseFragment {

    TextInputEditText oldPasswordEV;
    TextInputEditText newPasswordEV;
    TextInputEditText confirmPasswordEV;

    private Activity mActivity;
    private Unbinder unbinder;
    private View convertView;
    private HeaderLayout mHeaderLayout;
    private UserModel userModel;

    public static ChangePasswordFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        ChangePasswordFragment fragment = new ChangePasswordFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        convertView = inflater.inflate(R.layout.fragment_change_password, null);
        unbinder = ButterKnife.bind(this, convertView);
        return convertView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        oldPasswordEV = convertView.findViewById(R.id.old_password_et);
        newPasswordEV = convertView.findViewById(R.id.new_password_et);
        confirmPasswordEV = convertView.findViewById(R.id.confirm_password_et);
        this.mActivity = getActivity();
        this.userModel = new UserModel(mActivity);
        this.mHeaderLayout.setHeaderValues(0, "Change Password", 0);

    }

    @OnClick({R.id.verify_emailTV})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.verify_emailTV:
                callChangePasswordService();
                break;
        }
    }

    /**
     * Function to call service change password.
     */
    private void callChangePasswordService() {

        String oldPassword = oldPasswordEV.getText().toString().trim();
        String newPassword = newPasswordEV.getText().toString().trim();
        String confirmPassword = confirmPasswordEV.getText().toString().trim();

        if (oldPassword.length() == 0 || newPassword.length() == 0 || confirmPassword.length() == 0
                || !newPassword.equals(confirmPassword)) {
            if (oldPassword.length() == 0) {
                logConfig.printToast(mActivity, getResources().getString(R.string.enter_old_password));
            } else if (newPassword.length() == 0) {
                logConfig.printToast(mActivity, getResources().getString(R.string.enter_new_password));
            } else if (confirmPassword.length() == 0) {
                logConfig.printToast(mActivity, getResources().getString(R.string.enter_confirm_password));
            } else if (!newPassword.equals(confirmPassword)) {
                logConfig.printToast(mActivity, getResources().getString(R.string.password_do_not_match));
            }
        } else {

            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("action", "change_password");
                jsonObject.put("user_id", userModel.getUid());
                jsonObject.put("old_password", oldPassword);
                jsonObject.put("new_password", newPassword);

                NetworkApiCall service = new NetworkApiCall(mActivity, jsonObject, new ServiceResponse() {
                    @Override
                    public void requestResponse(String result) {
                        parseChangesPasswordResponse(result);
                    }
                });
                service.call();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }//callChangePasswordService

    /**
     * Function to parse api response.
     *
     * @param response A JSONObject return by server api
     */
    private void parseChangesPasswordResponse(String response) {

        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");
            String message = jsonObject.getString("message");

            if (status.equalsIgnoreCase("true")) {
                configData.displayAlert(mActivity, message, true);
            } else {
                configData.displayAlert(mActivity, message, false);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }//parseChangesPasswordResponse

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
