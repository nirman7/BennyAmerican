package com.benny.app.views.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.RelativeLayout;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.benny.app.R;
import com.benny.app.services.config.LogConfig;
import com.benny.app.views.customview.CustomButtonMedium;
import com.benny.app.views.customview.CustomEditTextValidation;
import com.benny.app.views.customview.CustomTextViewNormal;
import com.facebook.login.widget.LoginButton;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


/**
 * Created by Jitendra Sharma on 25/05/2020.
 */
public class LoginDialog extends DialogFragment {

    @BindView(R.id.emailEV)
    EditText emailEV;
    @BindView(R.id.passwordEV)
    EditText passwordEV;
    @BindView(R.id.keepLoginChk)
    CheckBox keepLoginChk;

    Unbinder unbinder;
    Activity activity;
    Context context;

    private SubmitCallback mSubmitCallback;
    private LogConfig logConfig = LogConfig.getInstance();
    private LoginButton loginButton;

    public LoginDialog() {
        // Required empty public constructor
    }

    public void setParameters(Activity activity, SubmitCallback submitCallback) {
        this.activity = activity;
        this.context = activity;
        this.mSubmitCallback = submitCallback;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getDialog().getWindow();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_login, container, false);
        unbinder = ButterKnife.bind(this, view);
        loginButton = view.findViewById(R.id.facebookLoginBtn);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSubmitCallback.callBackSocial(loginButton, "fb");
            }
        });
        keepLoginChk.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    }
                }
        );
        return view;
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.CustomDialog);
        super.show(manager, tag);
    }


    @OnClick({R.id.cancelBtn, R.id.forgotPasswordTV, R.id.submit_btn, R.id.signupBtn, R.id.googleBtn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.cancelBtn:
                dismiss();
                break;
            case R.id.forgotPasswordTV:
                mSubmitCallback.callBack("", "", "forgot");
                break;
            case R.id.submit_btn:
                callLoginMethod();
                break;
            case R.id.signupBtn:
                mSubmitCallback.callBack("", "", "signup");
                break;
            case R.id.googleBtn:
                mSubmitCallback.callBack("", "", "google");
                break;
        }
    }

    private void callLoginMethod() {

        String email = emailEV.getText().toString().trim();
        String password = passwordEV.getText().toString().trim();
        if(email.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_email));
        } else if(!logConfig.isValidEmail(email)) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_invalid_email));
        } else if(password.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_password));
        } else {
            mSubmitCallback.callBack(email, password, "login");
        }
    }

    public interface SubmitCallback {
        void callBack(String email, String password, String type);
        void callBackSocial(LoginButton loginButton, String type);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
