package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class CategoryModel implements Parcelable {

    String category_id;
    String category_name;
    String category_timestamp;
    String category_status;
    String img;
    String sub_id;
    String cat_id;
    String sub_name;

    protected CategoryModel(Parcel in) {
        category_id = in.readString();
        category_name = in.readString();
        category_timestamp = in.readString();
        category_status = in.readString();
        img = in.readString();
        sub_id = in.readString();
        cat_id = in.readString();
        sub_name = in.readString();
    }

    public static final Creator<CategoryModel> CREATOR = new Creator<CategoryModel>() {
        @Override
        public CategoryModel createFromParcel(Parcel in) {
            return new CategoryModel(in);
        }

        @Override
        public CategoryModel[] newArray(int size) {
            return new CategoryModel[size];
        }
    };

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getCategory_timestamp() {
        return category_timestamp;
    }

    public void setCategory_timestamp(String category_timestamp) {
        this.category_timestamp = category_timestamp;
    }

    public String getCategory_status() {
        return category_status;
    }

    public void setCategory_status(String category_status) {
        this.category_status = category_status;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getSub_name() {
        return sub_name;
    }

    public void setSub_name(String sub_name) {
        this.sub_name = sub_name;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(category_id);
        dest.writeString(category_name);
        dest.writeString(category_timestamp);
        dest.writeString(category_status);
        dest.writeString(img);
        dest.writeString(sub_id);
        dest.writeString(cat_id);
        dest.writeString(sub_name);
    }
}
