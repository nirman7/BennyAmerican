package com.benny.app.services.config;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.benny.app.viewsmodel.UserModel;

import org.json.JSONObject;

/**
 * Created by user on 18/04/2020.
 */
public class SharedStorage {

    private static SharedPreferences sharedPreferences = null;
    private static SharedStorage instance;
    private static Context mContext;

    private SharedStorage(Context context) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static SharedStorage getInstance(Context context) {
        mContext = context;
        if (instance == null) {
            instance = new SharedStorage(context);
        }
        return instance;
    }

    public void setLoginStatus(boolean status) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("loginStatus", status);
        editor.apply();
    }

    public boolean getLoginStatus() {
        return sharedPreferences.getBoolean("loginStatus", false);
    }


    public void setDeviceToken(String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("device_token", value);
        editor.apply();
    }

    public String getDeviceToken() {
        return sharedPreferences.getString("device_token", "");
    }

    public void setOrderTime(String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("order_time", value);
        editor.apply();
    }

    public String getOrderTime() {
        return sharedPreferences.getString("order_time", "");
    }

    public void setOrderDate(String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("order_date", value);
        editor.apply();
    }

    public String getOrderDate() {
        return sharedPreferences.getString("order_date", "");
    }

    public void setCartCount(int count) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("not_count", count);
        editor.apply();
    }

    public int getCartCount() {
        return sharedPreferences.getInt("not_count", 0);
    }


    public void logoutBtnAction(){
        setLoginStatus(false);
        setOrderDate("");
        setOrderTime("");
        setCartCount(0);
        JSONObject json = null;
        UserModel user = new UserModel(json);
        user.persist(mContext);

    }

}
