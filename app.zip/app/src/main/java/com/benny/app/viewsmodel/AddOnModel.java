package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class AddOnModel implements Parcelable {

    String add_id;
    String cat_id;
    String sub_id;
    String add_pro_name;
    String add_pro_price;
    String add_pro_offer_price;
    String add_pro_description;
    String add_pro_img;
    String add_pro_stock;
    String add_pro_mass;
    String add_pro_type;
    String add_pro_status;

    public String getAdd_id() {
        return add_id;
    }

    public void setAdd_id(String add_id) {
        this.add_id = add_id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getAdd_pro_description() {
        return add_pro_description;
    }

    public void setAdd_pro_description(String add_pro_description) {
        this.add_pro_description = add_pro_description;
    }

    public String getAdd_pro_img() {
        return add_pro_img;
    }

    public void setAdd_pro_img(String add_pro_img) {
        this.add_pro_img = add_pro_img;
    }

    public String getAdd_pro_mass() {
        return add_pro_mass;
    }

    public void setAdd_pro_mass(String add_pro_mass) {
        this.add_pro_mass = add_pro_mass;
    }

    public String getAdd_pro_name() {
        return add_pro_name;
    }

    public void setAdd_pro_name(String add_pro_name) {
        this.add_pro_name = add_pro_name;
    }

    public String getAdd_pro_offer_price() {
        return add_pro_offer_price;
    }

    public void setAdd_pro_offer_price(String add_pro_offer_price) {
        this.add_pro_offer_price = add_pro_offer_price;
    }

    public String getAdd_pro_price() {
        return add_pro_price;
    }

    public void setAdd_pro_price(String add_pro_price) {
        this.add_pro_price = add_pro_price;
    }

    public String getAdd_pro_status() {
        return add_pro_status;
    }

    public void setAdd_pro_status(String add_pro_status) {
        this.add_pro_status = add_pro_status;
    }

    public String getAdd_pro_type() {
        return add_pro_type;
    }

    public void setAdd_pro_stock(String add_pro_stock) {
        this.add_pro_stock = add_pro_stock;
    }

    public String getAdd_pro_stock() {
        return add_pro_stock;
    }

    public void setAdd_pro_type(String add_pro_type) {
        this.add_pro_type = add_pro_type;
    }

    protected AddOnModel(Parcel in) {
        add_id = in.readString();
        cat_id = in.readString();
        sub_id = in.readString();
        add_pro_name = in.readString();
        add_pro_price = in.readString();
        add_pro_offer_price = in.readString();
        add_pro_description = in.readString();
        add_pro_img = in.readString();
        add_pro_stock = in.readString();
        add_pro_mass = in.readString();
        add_pro_type = in.readString();
        add_pro_status = in.readString();
    }

    public static final Creator<AddOnModel> CREATOR = new Creator<AddOnModel>() {
        @Override
        public AddOnModel createFromParcel(Parcel in) {
            return new AddOnModel(in);
        }

        @Override
        public AddOnModel[] newArray(int size) {
            return new AddOnModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(add_id);
        dest.writeString(cat_id);
        dest.writeString(sub_id);
        dest.writeString(add_pro_name);
        dest.writeString(add_pro_price);
        dest.writeString(add_pro_offer_price);
        dest.writeString(add_pro_description);
        dest.writeString(add_pro_img);
        dest.writeString(add_pro_stock);
        dest.writeString(add_pro_mass);
        dest.writeString(add_pro_type);
        dest.writeString(add_pro_status);
    }
}
