package com.benny.app.viewsmodel;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONObject;

public class UserModel implements Parcelable {

    private static final String PREF_NAME = "UserPref";

    public UserModel() {

    }

    String uid;
    String user_fname;
    String user_lname;
    String user_mobile;
    String user_dob;
    String user_email;
    String user_password;
    String user_unit_number;
    String user_house_number;
    String user_street_name;
    String user_type;
    String user_suberb;
    String user_state;
    String user_lat;
    String user_lng;
    String user_pincode;
    String user_status;
    String user_image;
    String restaurant_id;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUser_fname() {
        return user_fname;
    }

    public void setUser_fname(String user_fname) {
        this.user_fname = user_fname;
    }

    public String getUser_lname() {
        return user_lname;
    }

    public void setUser_lname(String user_lname) {
        this.user_lname = user_lname;
    }

    public String getUser_mobile() {
        return user_mobile;
    }

    public void setUser_mobile(String user_mobile) {
        this.user_mobile = user_mobile;
    }

    public String getUser_dob() {
        return user_dob;
    }

    public void setUser_dob(String user_dob) {
        this.user_dob = user_dob;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getUser_unit_number() {
        return user_unit_number;
    }

    public void setUser_unit_number(String user_unit_number) {
        this.user_unit_number = user_unit_number;
    }

    public String getUser_house_number() {
        return user_house_number;
    }

    public void setUser_house_number(String user_house_number) {
        this.user_house_number = user_house_number;
    }

    public String getUser_street_name() {
        return user_street_name;
    }

    public void setUser_street_name(String user_street_name) {
        this.user_street_name = user_street_name;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getUser_suberb() {
        return user_suberb;
    }

    public void setUser_suberb(String user_suberb) {
        this.user_suberb = user_suberb;
    }

    public String getUser_state() {
        return user_state;
    }

    public void setUser_state(String user_state) {
        this.user_state = user_state;
    }

    public String getUser_pincode() {
        return user_pincode;
    }

    public void setUser_pincode(String user_pincode) {
        this.user_pincode = user_pincode;
    }

    public String getUser_lat() {
        return user_lat;
    }

    public void setUser_lat(String user_lat) {
        this.user_lat = user_lat;
    }

    public String getUser_lng() {
        return user_lng;
    }

    public void setUser_lng(String user_lng) {
        this.user_lng = user_lng;
    }

    public String getUser_status() {
        return user_status;
    }

    public void setUser_status(String user_status) {
        this.user_status = user_status;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getRestaurant_id() {
        return restaurant_id;
    }

    public void setRestaurant_id(String restaurant_id) {
        this.restaurant_id = restaurant_id;
    }

    public UserModel(JSONObject json) {

        if(json != null) {
            this.uid = json.optString("uid", "");
            this.user_fname = json.optString("user_fname", "");
            this.user_lname = json.optString("user_lname", "");
            this.user_mobile = json.optString("user_mobile", "");
            this.user_dob = json.optString("user_dob", "");
            this.user_email = json.optString("user_email", "");
            this.user_password = json.optString("user_password", "");
            this.user_unit_number = json.optString("user_unit_number", "");
            this.user_house_number = json.optString("user_house_number", "");
            this.user_street_name = json.optString("user_street_name", "");
            this.user_type = json.optString("user_type", "");
            this.user_suberb = json.optString("user_suberb", "");
            this.user_state = json.optString("user_state", "");
            this.user_lat = json.optString("user_lat", "");
            this.user_lng = json.optString("user_lng", "");
            this.user_pincode = json.optString("user_pincode", "");
            this.user_status = json.optString("user_status", "");
            this.user_image = json.optString("user_image", "");
        } else {
            this.uid = "";
            this.user_fname= "";
            this.user_lname= "";
            this.user_mobile= "";
            this.user_dob= "";
            this.user_email= "";
            this.user_password= "";
            this.user_unit_number= "";
            this.user_house_number= "";
            this.user_street_name= "";
            this.user_type= "";
            this.user_suberb= "";
            this.user_state= "";
            this.user_lat= "";
            this.user_lng= "";
            this.user_pincode= "";
            this.user_status= "";
            this.user_image= "";
            this.restaurant_id= "";
        }

    }

    public void persist(Context context) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("uid", uid);
        prefsEditor.putString("user_fname", user_fname);
        prefsEditor.putString("user_lname", user_lname);
        prefsEditor.putString("user_mobile", user_mobile);
        prefsEditor.putString("user_dob", user_dob);
        prefsEditor.putString("user_email", user_email);
        prefsEditor.putString("user_password", user_password);
        prefsEditor.putString("user_unit_number", user_unit_number);
        prefsEditor.putString("user_street_name", user_street_name);
        prefsEditor.putString("user_type", user_type);
        prefsEditor.putString("user_suberb", user_suberb);
        prefsEditor.putString("user_state", user_state);
        prefsEditor.putString("user_lat", user_lat);
        prefsEditor.putString("user_lng", user_lng);
        prefsEditor.putString("user_pincode", user_pincode);
        prefsEditor.putString("user_status", user_status);
        prefsEditor.putString("user_image", user_image);
        prefsEditor.apply();
    }

    public UserModel(Context context) {

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.uid = sharedPreferences.getString("uid", "");
        this.user_fname = sharedPreferences.getString("user_fname", "");
        this.user_lname = sharedPreferences.getString("user_lname", "");
        this.user_mobile = sharedPreferences.getString("user_mobile", "");
        this.user_dob = sharedPreferences.getString("user_dob", "");
        this.user_email = sharedPreferences.getString("user_email", "");
        this.user_password = sharedPreferences.getString("user_password", "");
        this.user_unit_number = sharedPreferences.getString("user_unit_number", "");
        this.user_house_number = sharedPreferences.getString("user_house_number", "");
        this.user_street_name = sharedPreferences.getString("user_street_name", "");
        this.user_type = sharedPreferences.getString("user_type", "");
        this.user_suberb = sharedPreferences.getString("user_suberb", "");
        this.user_state = sharedPreferences.getString("user_state", "");
        this.user_lat = sharedPreferences.getString("user_lat", "");
        this.user_lng = sharedPreferences.getString("user_lng", "");
        this.user_pincode = sharedPreferences.getString("user_pincode", "");
        this.user_status = sharedPreferences.getString("user_status", "");
        this.user_image = sharedPreferences.getString("user_image", "");
        this.restaurant_id = sharedPreferences.getString("restaurant_id", "");
    }

    protected UserModel(Parcel in) {
        uid = in.readString();
        user_fname = in.readString();
        user_lname = in.readString();
        user_mobile = in.readString();
        user_dob = in.readString();
        user_email = in.readString();
        user_password = in.readString();
        user_unit_number = in.readString();
        user_house_number = in.readString();
        user_street_name = in.readString();
        user_type = in.readString();
        user_suberb = in.readString();
        user_state = in.readString();
        user_lat = in.readString();
        user_lng = in.readString();
        user_pincode = in.readString();
        user_status = in.readString();
        user_image = in.readString();
        restaurant_id = in.readString();
    }

    public static final Creator<UserModel> CREATOR = new Creator<UserModel>() {
        @Override
        public UserModel createFromParcel(Parcel in) {
            return new UserModel(in);
        }

        @Override
        public UserModel[] newArray(int size) {
            return new UserModel[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(uid);
        dest.writeString(user_fname);
        dest.writeString(user_lname);
        dest.writeString(user_mobile);
        dest.writeString(user_dob);
        dest.writeString(user_email);
        dest.writeString(user_password);
        dest.writeString(user_unit_number);
        dest.writeString(user_house_number);
        dest.writeString(user_street_name);
        dest.writeString(user_type);
        dest.writeString(user_suberb);
        dest.writeString(user_state);
        dest.writeString(user_lat);
        dest.writeString(user_lng);
        dest.writeString(user_pincode);
        dest.writeString(user_status);
        dest.writeString(user_image);
        dest.writeString(restaurant_id);
    }
}
