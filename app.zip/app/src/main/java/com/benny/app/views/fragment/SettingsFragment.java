package com.benny.app.views.fragment;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.benny.app.BaseFragment;
import com.benny.app.R;
import com.benny.app.views.header.HeaderLayout;

import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * Created  on 18/04/2020.
 * @author Jitendra Sharma
 */
public class SettingsFragment extends BaseFragment {

    private View convertView;
    private HeaderLayout mHeaderLayout;
    private Unbinder unbinder;
    private FragmentActivity mActivity;

    public static SettingsFragment getInstance(HeaderLayout headerLayout, boolean backBtn) {
        SettingsFragment fragment = new SettingsFragment();
        fragment.mHeaderLayout = headerLayout;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.convertView = inflater.inflate(R.layout.fragment_settings, null);
        this.unbinder = ButterKnife.bind(this, convertView);
        return convertView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mActivity = getActivity();
        String title = getArguments().getString("Title");
        this.mHeaderLayout.setHeaderValues(0, title, 0);
        this.mHeaderLayout.setListenerItI(null, null);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick({R.id.imgChangePasslayout, R.id.about_us_layout, R.id.feedbackLayout})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imgChangePasslayout:
                switchFragment(0, getResources().getString(R.string.change_password));
                break;
            case R.id.about_us_layout:

                break;
            case R.id.feedbackLayout:
                switchFragment(3, getResources().getString(R.string.str_feedback));
                break;
        }
    }

    void switchFragment(int position, String title) {
        BaseFragment mBaseFragment;
        FragmentManager mFragmentManager;
        FragmentTransaction mFragmentTransaction;
        Bundle data = new Bundle();
        data.putString("Title", title);
        switch (position) {
            case 0: // ChangePassword
                mBaseFragment = ChangePasswordFragment.getInstance(mHeaderLayout, false);
                if (mBaseFragment != null) {
                    mBaseFragment.setArguments(data);
                    mFragmentManager = mActivity.getSupportFragmentManager();
                    mFragmentTransaction = mFragmentManager.beginTransaction();
                    mFragmentTransaction.replace(R.id.fragmentContainer, mBaseFragment, String.valueOf(position));
                    mFragmentTransaction.addToBackStack("ChangePasswordFragment");
                    mFragmentTransaction.commit();
                }

                break;
            case 1: //Abouts

                break;
        }
    }
}
