package com.benny.app.views.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.WebUrls;
import com.benny.app.viewsmodel.ProductModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Jitendra Sharma on 18/04/2020.
 */
public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {

    private ArrayList<ProductModel> mList = new ArrayList<>();
    private AdapterBtnCallBack mCallBack;
    private Activity mActivity;
    private ConfigData configData = ConfigData.getInstance();

    public GalleryAdapter(Activity activity, AdapterBtnCallBack callBack) {
        this.mCallBack = callBack;
        this.mActivity = activity;
    }

    public void setList(ArrayList list) {
        this.mList = list;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.galery_list_item, parent, false);

        return new ViewHolder(itemView, new ViewHolder.RecyclerViewClickListener() {
            @Override
            public void onClick(View view, int position) {
                mCallBack.itemClickListener(mList.get(position), "view");
            }
        });
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final ProductModel model = mList.get(position);

        String url = WebUrls.IMAGE_URL + model.getPro_img();
        configData.setPicasoImageLoader(mActivity, holder.image, url, R.drawable.place_holder);

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.image)
        ImageView image;

        RecyclerViewClickListener mListener;

        ViewHolder(View view, RecyclerViewClickListener listener) {
            super(view);
            ButterKnife.bind(this, view);
            this.mListener = listener;
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v, getAdapterPosition());
        }

        public interface RecyclerViewClickListener {
            void onClick(View view, int position);
        }
    }

    public interface AdapterBtnCallBack {
        void itemClickListener(ProductModel model, String type);
    }

}
