package com.benny.app.viewsmodel;

import android.os.Parcel;
import android.os.Parcelable;

public class ProductModel implements Parcelable {

    public ProductModel() {

    }

    String pro_id;
    String sub_id;
    String pro_name;
    String pro_price;
    String pro_offer_price;
    String pro_description;
    String pro_img;
    String pro_stock;
    String pro_status;
    String timestamp;

    public String getPro_id() {
        return pro_id;
    }

    public void setPro_id(String pro_id) {
        this.pro_id = pro_id;
    }

    public String getSub_id() {
        return sub_id;
    }

    public void setSub_id(String sub_id) {
        this.sub_id = sub_id;
    }

    public String getPro_name() {
        return pro_name;
    }

    public void setPro_name(String pro_name) {
        this.pro_name = pro_name;
    }

    public String getPro_price() {
        return pro_price;
    }

    public void setPro_price(String pro_price) {
        this.pro_price = pro_price;
    }

    public String getPro_offer_price() {
        return pro_offer_price;
    }

    public void setPro_offer_price(String pro_offer_price) {
        this.pro_offer_price = pro_offer_price;
    }

    public String getPro_description() {
        return pro_description;
    }

    public void setPro_description(String pro_description) {
        this.pro_description = pro_description;
    }

    public String getPro_img() {
        return pro_img;
    }

    public void setPro_img(String pro_img) {
        this.pro_img = pro_img;
    }

    public String getPro_stock() {
        return pro_stock;
    }

    public void setPro_stock(String pro_stock) {
        this.pro_stock = pro_stock;
    }

    public String getPro_status() {
        return pro_status;
    }

    public void setPro_status(String pro_status) {
        this.pro_status = pro_status;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    protected ProductModel(Parcel in) {
        pro_id = in.readString();
        sub_id = in.readString();
        pro_name = in.readString();
        pro_price = in.readString();
        pro_offer_price = in.readString();
        pro_description = in.readString();
        pro_img = in.readString();
        pro_stock = in.readString();
        pro_status = in.readString();
        timestamp = in.readString();
    }

    public static final Creator<ProductModel> CREATOR = new Creator<ProductModel>() {
        @Override
        public ProductModel createFromParcel(Parcel in) {
            return new ProductModel(in);
        }

        @Override
        public ProductModel[] newArray(int size) {
            return new ProductModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(pro_id);
        dest.writeString(sub_id);
        dest.writeString(pro_name);
        dest.writeString(pro_price);
        dest.writeString(pro_offer_price);
        dest.writeString(pro_description);
        dest.writeString(pro_img);
        dest.writeString(pro_stock);
        dest.writeString(pro_status);
        dest.writeString(timestamp);
    }
}
