package com.benny.app.views.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.benny.app.R;
import com.benny.app.viewsmodel.SliderModel;
import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Jitendra Sharma on 24/05/2020.
 */
public class SliderListAdapter extends RecyclerView.Adapter<SliderListAdapter.ItemViewHolder> {

    public ArrayList<SliderModel> mList = new ArrayList<>();
    private AdapterCallBack mCallBack;
    private Activity mActivity;

    public SliderListAdapter(Activity activity, AdapterCallBack callBack) {
        this.mActivity = activity;
        this.mCallBack = callBack;
    }

    public void setList(ArrayList mArray) {
        this.mList = mArray;
        notifyDataSetChanged();
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.slider_list_item, parent, false);

        return new ItemViewHolder(itemView, new ItemViewHolder.RecyclerViewClickListener() {
            @Override
            public void onClick(View view, int position) {
                mCallBack.itemClickListener(mList.get(position), "view");
            }
        });
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, final int position) {
        final SliderModel model = mList.get(position);
        holder.menuIV.setImageResource(model.getImage());
        holder.nameTV.setText(model.getName());

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @BindView(R.id.iconImg)
        ImageView menuIV;
        @BindView(R.id.nameTV)
        TextView nameTV;

        RecyclerViewClickListener mListener;

        ItemViewHolder(View view, RecyclerViewClickListener listener) {
            super(view);
            ButterKnife.bind(this, view);
            this.mListener = listener;
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v, getAdapterPosition());
        }

        public interface RecyclerViewClickListener {
            void onClick(View view, int position);
        }
    }

    public interface AdapterCallBack {
        void itemClickListener(SliderModel model, String type);
    }

}
