package com.benny.app;

import android.content.Context;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

/**
 * Created by user on 18/04/2020.
 */
public class Application extends MultiDexApplication {

    private static Application  mInstance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

    }
    public static synchronized Application getInstance() {
        return mInstance;
    }


    public static Context getAppContext(){
        return mInstance.getApplicationContext();
    }

}
