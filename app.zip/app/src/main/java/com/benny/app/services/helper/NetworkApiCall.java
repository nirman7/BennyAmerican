package com.benny.app.services.helper;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.benny.app.R;
import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.LogConfig;
import com.benny.app.services.config.WebUrls;

import org.json.JSONObject;

/**
 * Created by user on 18/04/2020.
 */
public class NetworkApiCall {

    private String TAG = "NetworkApiCall: ";
    private Activity mActivity = null;
    private Context context;
    private String responseString = "";
    private ProgressDialog pDialog = null;
    private JSONObject mJSONObject;
    private ServiceResponse mServiceResponse;
    private int MY_SOCKET_TIMEOUT_MS = 30000;
    private ConfigData mConfigData = ConfigData.getInstance();
    private LogConfig logConfig = LogConfig.getInstance();
    private String network_error;
    private RequestQueue mRequestQueue;

    public NetworkApiCall(Activity activity, JSONObject jsonObject, ServiceResponse serviceResponse) {
        this.mActivity = activity;
        this.context = activity;
        this.mJSONObject = jsonObject;
        this.mServiceResponse = serviceResponse;
        this.network_error = context.getResources().getString(R.string.str_no_network);
        this.mRequestQueue = VolleySingleton.getsInstance().getRequestQueue();
    }

    public NetworkApiCall(Context context, JSONObject jsonObject, ServiceResponse serviceResponce) {
        this.context = context;
        this.mJSONObject = jsonObject;
        this.mServiceResponse = serviceResponce;
        this.network_error = context.getResources().getString(R.string.str_no_network);
        this.mRequestQueue = VolleySingleton.getsInstance().getRequestQueue();
    }

    public void call() {

        logConfig.printV(TAG, WebUrls.MAIN_URL + mJSONObject.toString());
        if (mActivity != null) {
            SpannableString spandle = new SpannableString("Loading...");
            spandle.setSpan(new ForegroundColorSpan(Color.GRAY), 0, spandle.length(), 0);
            pDialog = new ProgressDialog(mActivity);
            pDialog.setMessage(spandle);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        if (isConnectingToInternet()) {
            responseString = "";
            JsonObjectRequest jor = new JsonObjectRequest(Request.Method.POST, WebUrls.MAIN_URL, mJSONObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            logConfig.printP(TAG, "JSONObject: " + response.toString());
                            //To dismiss progress dialog.
                            responseString = response.toString();
                            onPostExecute(responseString);
                        }//if
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            logConfig.printP(TAG, "VolleyError: " + error.getMessage());
                            responseString = "Error";
                            onPostExecute(responseString);
                        }
                    });
            jor.setRetryPolicy(new DefaultRetryPolicy(MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            mRequestQueue.add(jor);
        } else {
            onPostExecute(network_error);
        }
    }

    public void callWithoutProgressDialog() {

        logConfig.printV(TAG, WebUrls.MAIN_URL + mJSONObject.toString());
        if (isConnectingToInternet()) {
            JsonObjectRequest jor = new JsonObjectRequest(Request.Method.POST, WebUrls.MAIN_URL, mJSONObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            logConfig.printP(TAG, "response: " + response.toString());
                            //To dismiss progress dialog.
                            responseString = response.toString();
                            onPostExecute(responseString);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            responseString = "Error";
                            onPostExecute(responseString + " :  " + error);
                        }
                    });
            jor.setRetryPolicy(new DefaultRetryPolicy(MY_SOCKET_TIMEOUT_MS, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            mRequestQueue.add(jor);
        } else {
            onPostExecute(network_error);
        }
    }

    public void onPostExecute(String result) {
        try {
            if (pDialog != null && pDialog.isShowing()) {
                pDialog.dismiss();
            }
        } catch (Exception e) {
            //e.printStackTrace();
        }

        if (!result.equals("") && !result.equals("Error") && !result.equals(network_error)) {
            mServiceResponse.requestResponse(result);
        } else {
            if (mActivity != null) {
                if (result.equals("") || result.equals("Error")) {
                    mConfigData.displayAlert(mActivity, context.getResources().getString(R.string.some_thing_went_wrong_msg), false);
                } else {
                    mConfigData.displayAlert(mActivity, network_error, false);
                }
            } else {
                logConfig.printToast(context, network_error);
            }
        }
    }

    public boolean isConnectingToInternet() {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }


}
