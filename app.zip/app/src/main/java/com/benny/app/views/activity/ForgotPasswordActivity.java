package com.benny.app.views.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ForgotPasswordActivity extends BaseFragmentActivity {

    @BindView(R.id.mobileNoEV)
    EditText mobileNoEV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        ButterKnife.bind(this);

        setHeader(R.drawable.ic_arrow_left, 0, getResources().getString(R.string.str_forgot_password),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                    }
                }, null);

    }

    @OnClick({R.id.forgotPasswordBtn})
    public void onViewClicked(View view) {
        logConfig.hideKeyBoard(this);
        switch (view.getId()) {
            case R.id.forgotPasswordBtn:
                callServiceForgotPassword();
                break;
        }
    }

    void callServiceForgotPassword() {

        String mobileNo = mobileNoEV.getText().toString().trim();
        if (mobileNo.length() == 0) {
            logConfig.printToast(this, getResources().getString(R.string.str_enter_mobile_number));
        } else if (mobileNo.length()<10) {
            logConfig.printToast(this, getResources().getString(R.string.str_invalid_mobile_number));
        } else {

            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("action", "forgotPassword");
                jsonObject.put("mobile", mobileNo);
                NetworkApiCall apiCall = new NetworkApiCall(this, jsonObject, new ServiceResponse() {
                    @Override
                    public void requestResponse(String result) {
                        parseResponse(result);
                    }
                });
                apiCall.call();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    void parseResponse(String response) {

        try {
            JSONObject obj = new JSONObject(response);
            String status = obj.getString("status");
            String message = obj.getString("message");
            if (status.equals("true")) {
                configData.displayAlert(this, message, true);
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_left_exit);
            } else {
                configData.displayAlert(this, message, false);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_left_exit);
    }
}
