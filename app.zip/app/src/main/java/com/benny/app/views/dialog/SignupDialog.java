package com.benny.app.views.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.benny.app.R;
import com.benny.app.services.config.LogConfig;
import com.benny.app.services.config.SharedStorage;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.util.Constant;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


/**
 * Created by Jitendra Sharma on 24/05/2020.
 */
public class SignupDialog extends DialogFragment {

    @BindView(R.id.firstNameEV)
    EditText firstNameEV;
    @BindView(R.id.lastNameEV)
    EditText lastNameEV;
    @BindView(R.id.emailEV)
    EditText emailEV;
    @BindView(R.id.mobileNoEV)
    EditText mobileNoEV;
    @BindView(R.id.passwordEV)
    EditText passwordEV;
    @BindView(R.id.unitNumberEV)
    EditText unitNumberEV;
    @BindView(R.id.houseNumberEV)
    EditText houseNumberEV;
    @BindView(R.id.streetNameEV)
    EditText streetNameEV;
    @BindView(R.id.suberbEV)
    EditText suberbEV;
    @BindView(R.id.stateEV)
    EditText stateEV;
    @BindView(R.id.pinCodeEV)
    EditText pinCodeEV;

    private Unbinder unbinder;
    private Activity activity;
    private Context context;
    private SubmitCallback mSubmitCallback;
    private LogConfig logConfig = LogConfig.getInstance();
    private SharedStorage sharedStorage;
    private LoginButton loginButton;

    public SignupDialog() {
        // Required empty public constructor
    }

    public void setParameters(Activity activity, SubmitCallback submitCallback) {
        this.activity = activity;
        this.context = activity;
        this.mSubmitCallback = submitCallback;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getDialog().getWindow();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        this.sharedStorage = SharedStorage.getInstance(activity);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_signup, container, false);
        unbinder = ButterKnife.bind(this, view);
        loginButton = view.findViewById(R.id.facebookLoginBtn);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSubmitCallback.callBackSocial(loginButton, "fb");
            }
        });

        return view;
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.CustomDialog);
        super.show(manager, tag);
    }


    @OnClick({R.id.cancelBtn, R.id.submit_btn, R.id.googleBtn, R.id.loginBtn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.cancelBtn:
                dismiss();
                break;
            case R.id.submit_btn:
                callSignupMethod();
                break;
            case R.id.googleBtn:
                mSubmitCallback.callBack(null, "google");
                break;
            case R.id.loginBtn:
                mSubmitCallback.callBack(null, "login");
                break;
        }
    }

    private void callSignupMethod() {

        String firstName = firstNameEV.getText().toString().trim();
        String lastName = lastNameEV.getText().toString().trim();
        String email = emailEV.getText().toString().trim();
        String mobileNo = mobileNoEV.getText().toString().trim();
        String password = passwordEV.getText().toString().trim();
        String unitNumber = unitNumberEV.getText().toString().trim();
        String houseNumber = houseNumberEV.getText().toString().trim();
        String streetName = streetNameEV.getText().toString().trim();
        String suberb = suberbEV.getText().toString().trim();
        String state = stateEV.getText().toString().trim();
        String pinCode = pinCodeEV.getText().toString().trim();

        if (firstName.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_first_name));
        } else if (lastName.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_last_name));
        } else if (email.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_email));
        } else if (!logConfig.isValidEmail(email)) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_invalid_email));
        } else if (mobileNo.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_mobile_number));
        } else if (mobileNo.length() < 10) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_invalid_mobile_number));
        } else if (password.length() == 0) {
            logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_password));
        } else {

            try {
                JSONObject mJsonObject = new JSONObject();
                mJsonObject.put("action", "register_user");
                mJsonObject.put("user_fname", firstName);
                mJsonObject.put("user_lname", lastName);
                mJsonObject.put("user_email", email);
                mJsonObject.put("user_mobile", mobileNo);
                mJsonObject.put("user_password", password);
                mJsonObject.put("user_unit_number", unitNumber);
                mJsonObject.put("user_house_number", houseNumber);
                mJsonObject.put("user_street_name", streetName);
                mJsonObject.put("user_suberb", suberb);
                mJsonObject.put("user_state", state);
                mJsonObject.put("user_pincode", pinCode);
                mJsonObject.put("user_type", WebUrls.USER);
                mJsonObject.put("device_token", sharedStorage.getDeviceToken());
                mJsonObject.put("device_type", Constant.DEVICE_TYPE);
                mSubmitCallback.callBack(mJsonObject, "signup");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public interface SubmitCallback {
        void callBack(JSONObject mJsonObject, String type);

        void callBackSocial(LoginButton loginButton, String type);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
