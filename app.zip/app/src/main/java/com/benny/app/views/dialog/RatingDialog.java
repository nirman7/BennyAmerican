package com.benny.app.views.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.RelativeLayout;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.benny.app.R;
import com.benny.app.views.customview.CustomButtonMedium;
import com.benny.app.views.customview.CustomEditTextValidation;
import com.benny.app.views.customview.CustomTextViewNormal;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


/**
 * Created by Jitendra Sharma on 20/05/2020.
 */
public class RatingDialog extends DialogFragment {

    @BindView(R.id.dialogTitle)
    CustomTextViewNormal dialogTitle;
    @BindView(R.id.ratingBar)
    RatingBar ratingBar;
    @BindView(R.id.descriptionTitle)
    CustomTextViewNormal descriptionTitle;
    @BindView(R.id.productDescriptionInput)
    CustomEditTextValidation productDescriptionInput;
    @BindView(R.id.descriptionLayout)
    RelativeLayout descriptionLayout;
    @BindView(R.id.submit_btn)
    CustomButtonMedium submitBtn;
    Unbinder unbinder;
    private Button mBtnRegister, mBtnCancel;
    Activity activity;
    Context context;
    String mTitle;
    private SubmitCallback mSubmitCallback;

    public RatingDialog() {
        // Required empty public constructor
    }

    public void getPerameter(Activity activity, String title, SubmitCallback submitCallback) {
        this.activity = activity;
        this.context = activity;
        this.mTitle = title;
        this.mSubmitCallback = submitCallback;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getDialog().getWindow();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_rating, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }


    @Override
    public void show(FragmentManager manager, String tag) {
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.CustomDialog);
        super.show(manager, tag);

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @OnClick(R.id.submit_btn)
    public void onViewClicked() {

        String rating = "" + ratingBar.getRating();
        String description = descriptionTitle.getText().toString();
        mSubmitCallback.callBack(rating, description);


    }

    public interface SubmitCallback {
        void callBack(String rating, String description);
    }
}
