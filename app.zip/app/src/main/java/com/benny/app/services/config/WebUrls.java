package com.benny.app.services.config;

/**
 * Created by user on 18/04/2020.
 */
public class WebUrls {

    public static final String HOST = "http://puinfotech.com/bennys_api/";
    public static final String MAIN_URL = HOST + "bennys_webservice.php";
    public static final String UPLOAD_IMAGE_URL = HOST + "bennys_webservice.php";
    public static String IMAGE_URL = HOST+"uploads/";

    public static final String USER = "USER";
    public static final String PAYMENT_URL = HOST + "pay.php?";
    public static final String EXAM_RESULT_URL = HOST + "result.php?";
    public static final String EXAM_RANKING_URL = HOST + "ranking.php?";
    public static final String ABOUT_US_URL = HOST + "about_us.html";
    public static final String PRIVACY_POLICY_URL = HOST + "privacy_policy.html";
    public static final String TERMS_CONDITION_URL = HOST + "terms_and_condition.html";

    public static final String FACEBOOK_URL = "https://www.facebook.com/bennysmorphettvale/";
    public static final String GOOGLE_URL = "https://www.google.com/bennysmorphettvale/";
    public static final String TWITTER_URL = "https://instagram.com/bennysamericantakeaway?igshid=1r4xvdu21dbab";

    public static String ACTION_NOTIFICATION = "com.benny.ACTION_NOTIFICATION";
    public static String ACTION_CART_COUNT = "com.benny.ACTION_CART_COUNT";
    public static String ACTION_SENT_TEXT = "com.benny.ACTION_SENT_TEXT";
    public static String ACTION_ORDER_PLACE = "com.benny.ACTION_ORDER_PLACE";
    public static String ACTION_PRODUCT_STATUS = "com.benny.ACTION_PRODUCT_STATUS";
}
