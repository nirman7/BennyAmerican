package com.benny.app.views.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.benny.app.BaseFragmentActivity;
import com.benny.app.R;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.NetworkApiCall;
import com.benny.app.services.helper.ServiceResponse;
import com.benny.app.services.util.Constant;
import com.benny.app.views.dialog.ForgotPasswordDialog;
import com.benny.app.views.dialog.LoginDialog;
import com.benny.app.views.dialog.SignupDialog;
import com.benny.app.viewsmodel.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SelectRestaurantActivity extends BaseFragmentActivity {

    @BindView(R.id.nowBtn)
    TextView nowBtn;
    @BindView(R.id.laterBtn)
    TextView laterBtn;

    private Activity mActivity;
    private UserModel userModel;
    private String orderType = "now";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_resturant);
        this.mActivity = SelectRestaurantActivity.this;
        this.userModel = new UserModel(this);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.layoutRestaurant1, R.id.layoutRestaurant2, R.id.nowBtn, R.id.laterBtn})
    public void onViewClicked(View view) {
        logConfig.hideKeyBoard(this);
        Intent mIntent = null;
        switch (view.getId()) {
            case R.id.layoutRestaurant1:
                userModel.setRestaurant_id("1");
                Intent intent = new Intent(this, DeliveryDateTimeActivity.class);
                intent.putExtra("Type","home");
                intent.putExtra("Order_Type", orderType);
                startActivity(intent);
                break;
            case R.id.layoutRestaurant2:
                userModel.setRestaurant_id("2");
                Intent intent1 = new Intent(this, DeliveryDateTimeActivity.class);
                intent1.putExtra("Type","home");
                intent1.putExtra("Order_Type", orderType);
                startActivity(intent1);
                break;
            case R.id.nowBtn:
                orderType = "now";
                nowBtn.setBackgroundResource(R.drawable.ic_red_btn_bg);
                laterBtn.setBackgroundResource(R.drawable.ic_later_border);
                break;
            case R.id.laterBtn:
                orderType = "later";
                nowBtn.setBackgroundResource(R.drawable.ic_now_border);
                laterBtn.setBackgroundResource(R.drawable.ic_red_btn_bg);
                break;
        }
    }

}