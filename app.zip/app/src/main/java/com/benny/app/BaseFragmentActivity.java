package com.benny.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.benny.app.services.config.ConfigData;
import com.benny.app.services.config.SharedStorage;
import com.benny.app.services.util.ImageFilePath;
import com.benny.app.services.config.LogConfig;
import com.benny.app.services.config.WebUrls;
import com.benny.app.services.helper.HttpRequestUtility;
import com.benny.app.services.helper.ServiceResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 18/04/2020.
 */
public class BaseFragmentActivity  extends FragmentActivity {

    public TextView actionBarTitle;
    public ImageView rightButton;
    public ImageView leftButton;
    public ProgressBar loadingPb;
    public RelativeLayout headerLayoutTop;
    public Context context;
    public static final String IMAGE_UNSPECIFIED = "image/*";
    public LogConfig logConfig = LogConfig.getInstance();
    public ConfigData configData = ConfigData.getInstance();
    public SharedStorage mSharedStorage;
    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        this.mActivity = this;
        this.mSharedStorage = SharedStorage.getInstance(this);
    }

    public void setHeader(int leftButtonId, int rightButtonId, String title, View.OnClickListener
            leftButtonListener, View.OnClickListener rightButtonListener) {

        headerLayoutTop = (RelativeLayout) ((Activity) context).findViewById(R.id.headerLayoutTop);
        actionBarTitle = (TextView) ((Activity) context).findViewById(R.id.header_tv);
        rightButton = (ImageView) ((Activity) context).findViewById(R.id.right_button);
        leftButton = (ImageView) ((Activity) context).findViewById(R.id.back_button);
        loadingPb = (ProgressBar) ((Activity) context).findViewById(R.id.loading_h_pb);

        actionBarTitle.setText(title);
        leftButton.setImageResource(leftButtonId);
        leftButton.setOnClickListener(leftButtonListener);
        rightButton.setImageResource(rightButtonId);
        rightButton.setOnClickListener(rightButtonListener);

        rightButton.setVisibility(rightButtonId > 0 ? View.VISIBLE : View.GONE);
    }

    public void setHeaderTitle(String title) {
        actionBarTitle.setText(title);
    }

    public void hideHeaderLayout(int value) {
        if (value == 0) {
            headerLayoutTop.setVisibility(View.GONE);
        } else {
            headerLayoutTop.setVisibility(View.VISIBLE);
        }

    }

    public void hideRightButton() {
        rightButton.setVisibility(View.INVISIBLE);
    }

    public void showLoader(boolean show) {
        loadingPb.setVisibility(show ? View.VISIBLE : View.GONE);
        rightButton.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    public ImageView getRightButton() {
        return rightButton;
    }


    /**
     * Create a chooser intent to select the source to get image from.<br/>
     * The source can be camera's (ACTION_IMAGE_CAPTURE) or gallery's (ACTION_GET_CONTENT).<br/>
     * All possible sources are added to the intent chooser.
     */
    public Intent getPickImageChooserIntent() {

        ImageFilePath mImageFilePath = new ImageFilePath(((Activity) context));
        // Determine Uri of camera image to save.
        Uri outputFileUri = mImageFilePath.getCaptureImageOutputUri();
        List<Intent> allIntents = new ArrayList<>();
        PackageManager packageManager = getPackageManager();

        // collect all camera intents
        Intent captureIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        List<ResolveInfo> listCam = packageManager.queryIntentActivities(captureIntent, 0);
        for (ResolveInfo res : listCam) {
            Intent intent = new Intent(captureIntent);
            intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
            intent.setPackage(res.activityInfo.packageName);
            if (outputFileUri != null) {
                intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
            }
            allIntents.add(intent);
        }

        // collect all gallery intents
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType(IMAGE_UNSPECIFIED);
        //you must setup two line below
        galleryIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        galleryIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        List<ResolveInfo> listGallery = packageManager.queryIntentActivities(galleryIntent, 0);
        for (ResolveInfo res : listGallery) {
            Intent intent = new Intent(galleryIntent);
            intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
            intent.setPackage(res.activityInfo.packageName);
            allIntents.add(intent);
        }

        // the main intent is the last in the list (fucking android) so pickup the useless one
        Intent mainIntent = allIntents.get(allIntents.size() - 1);
        for (Intent intent : allIntents) {
            if (intent.getComponent().getClassName().equals("com.android.documentsui.DocumentsActivity")) {
                mainIntent = intent;
                break;
            }
        }
        allIntents.remove(mainIntent);
        // Create a chooser from the main intent
        Intent chooserIntent = Intent.createChooser(mainIntent, "Select source");
        // Add all other intents
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,
                allIntents.toArray(new Parcelable[allIntents.size()]));
        return chooserIntent;
    }

    public void uploadSingleImage(String image, final ServiceResponse serviceResponce) {

        logConfig.printD("uploadSingleImage ", "image: " + image);

        HashMap<String, String> parameter = new HashMap<>();
        HashMap<String, String> bodybodyParameter = new HashMap<>();
        bodybodyParameter.put("action", "no_image");

        ArrayList<String> filePath = new ArrayList<>();
        if (image != null && image.length() != 0) {
            filePath.add(image);
        }

        HttpRequestUtility request = new HttpRequestUtility(parameter, bodybodyParameter, filePath,
                "pic_bs", WebUrls.UPLOAD_IMAGE_URL, HttpRequestUtility.MULTIPART,
                1001, this, true,
                new HttpRequestUtility.HttpRequestResponseListener() {
                    @Override
                    public void callBackHttpRequest(String strResponse, int response_code) {
                        logConfig.printD("ImageUploading Response: ", strResponse);

                        try {

                            JSONObject resultData = new JSONObject(strResponse);
                            String status = resultData.getString("status");
                            if (status.equals("true")) {
                                JSONObject jObject = resultData.getJSONObject("data");
                                String picture = jObject.getString("image_name");
                                serviceResponce.requestResponse(picture);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
        request.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

    }

    public void setSpinnerSize(Spinner spinner) {
        try {
            Field popup = Spinner.class.getDeclaredField("mPopup");
            popup.setAccessible(true);
            // Get private mPopup member variable and try cast to ListPopupWindow
            android.widget.ListPopupWindow popupWindow = (android.widget.ListPopupWindow) popup.get(spinner);

            //float height = (float) mActivity.getResources().getDimension(R.dimen.item_detail_image_large);
            // Set popupWindow height to 500px
            popupWindow.setHeight((int) ConfigData.convertDpToPixel(200, mActivity));
        } catch (NoClassDefFoundError | ClassCastException | NoSuchFieldException | IllegalAccessException e) {
            // silently fail...
        }
    }


}
