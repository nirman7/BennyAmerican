package com.benny.app.views.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.benny.app.R;
import com.benny.app.services.config.LogConfig;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


/**
 * Created by Jitendra Sharma on 27/05/2020.
 */
public class ForgotPasswordDialog extends DialogFragment {

    @BindView(R.id.emailEV)
    EditText emailEV;

    private Unbinder unbinder;
    private Activity activity;
    private Context context;

    private SubmitCallback mSubmitCallback;
    private LogConfig logConfig = LogConfig.getInstance();

    public ForgotPasswordDialog() {
        // Required empty public constructor
    }

    public void setParameters(Activity activity, SubmitCallback submitCallback) {
        this.activity = activity;
        this.context = activity;
        this.mSubmitCallback = submitCallback;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getDialog().getWindow();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.dialog_forgot_password, container, false);
        unbinder = ButterKnife.bind(this, view);

        return view;
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        setStyle(DialogFragment.STYLE_NO_FRAME, R.style.CustomDialog);
        super.show(manager, tag);
    }


    @OnClick({R.id.cancelBtn, R.id.submit_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.cancelBtn:
                dismiss();
                break;
            case R.id.submit_btn:
                String email = emailEV.getText().toString().trim();
                if(email.length() == 0) {
                    logConfig.printToast(activity, activity.getResources().getString(R.string.str_enter_email));
                } else if(!logConfig.isValidEmail(email)) {
                    logConfig.printToast(activity, activity.getResources().getString(R.string.str_invalid_email));
                } else {
                    mSubmitCallback.callBack(email, "forgot");
                }
                break;
        }
    }

    public interface SubmitCallback {
        void callBack(String email, String type);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

}
